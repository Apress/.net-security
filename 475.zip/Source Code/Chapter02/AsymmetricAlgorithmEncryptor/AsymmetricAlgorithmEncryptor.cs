using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace APress.DotNetSecurity.Chapter2.AsymmetricAlgorithmEncryptor
{
	class AsymmetricAlgorithmEncryptorTester
	{
		static void Main(string[] args)
		{
			try
			{
				String adPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				Console.WriteLine("Creating the random data file information...");
				RandomNumberGenerator rng = new RNGCryptoServiceProvider();
				byte[] randomBytes = new byte[1000];
				rng.GetNonZeroBytes(randomBytes);

				FileStream fCreate = new FileStream(adPath + @"\randomData.dat", 
					FileMode.Create, FileAccess.Write);

				Console.WriteLine("Writing the random data to the file " + 
					adPath + @"\randomData.dat...");
				fCreate.Write(randomBytes, 0, (int)randomBytes.Length);
				fCreate.Close();

				FileStream fin = new FileStream(adPath + @"\randomData.dat", 
					FileMode.Open, FileAccess.Read);
				FileStream fdec = new FileStream(adPath + @"\randomDataOut.dat", 
					FileMode.OpenOrCreate, FileAccess.Write);

				//  Read in the file data.
				RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)RSA.Create();
				int len = 0, readBytes = 0, dataSize = 0;
				
				if(1024 == rsa.KeySize)
				{
					dataSize = 16;
				}
				else
				{
					dataSize = 5;
				}

				Console.WriteLine("Data length is " + dataSize.ToString());

				byte[] finData = new byte[dataSize], rsaEncrypt = null, 
					rsaDecrypt = null;

				Console.WriteLine("Encrypting the data and decrypting the data to " +
					adPath + @"\randomDataOut.dat...");

				while(readBytes < fin.Length)
				{
					len = fin.Read(finData, 0, dataSize);
					readBytes += len;
					//  Encrypt the data.
					rsaEncrypt = rsa.Encrypt(finData, false);
					//  Decrypt the data.
					rsaDecrypt = rsa.Decrypt(rsaEncrypt, false);
					fdec.Write(rsaDecrypt, 0, (int)rsaDecrypt.Length);
				}
				fdec.Close();
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b);
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}	
	}
}

