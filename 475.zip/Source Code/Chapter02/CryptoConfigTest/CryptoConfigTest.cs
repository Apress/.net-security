using System;
using System.Security.Cryptography;

namespace APress.DotNetSecurity.Chapter2.CryptoConfigTest
{
	class CryptoConfigTester
	{
		static void Main(string[] args)
		{
			try
			{
				//  NOTE:  This code assumes that you've added the proper XML
				//  elements to machine.config that were discussed 
				//  in the "CryptoConfig and machine.config" section
				//  of Chapter 2.
				Console.WriteLine("Creating a hash algorithm via the APressSHA mapping name...");
				HashAlgorithm hashAPressSHA = (HashAlgorithm)CryptoConfig.CreateFromName("ApressSHA");
				Console.WriteLine("Creation done - hash type is " + 
					hashAPressSHA.GetType().FullName);
				Console.WriteLine("Creating a hash algorithm via the SHA1 mapping name...");
				HashAlgorithm hashSHA1 = (HashAlgorithm)CryptoConfig.CreateFromName("SHA1");
				Console.WriteLine("Creation done - hash type is " + 
					hashSHA1.GetType().FullName);
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
	}
}
