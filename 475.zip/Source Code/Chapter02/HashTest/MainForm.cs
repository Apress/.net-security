namespace HelloWorld
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
	using System.Text;
    using System.WinForms;
    using System.Data;
	using System.Reflection;
	using System.Security.Cryptography;

    /// <summary>
    ///    Summary description for MainForm.
    /// </summary>
    public class MainForm : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.Label lblHashLength;
		private System.WinForms.Label label2;
		private System.WinForms.Label label1;
		private System.WinForms.ComboBox cboAlgorithms;
		private System.WinForms.Label lblEncoding;
		private System.WinForms.ComboBox cboEncoding;
		private System.WinForms.Label lblPreImage;
		private System.WinForms.Label lblAlgorithm;
		private System.WinForms.Label lblHashValue;
		private System.WinForms.TextBox txtHash;
		private System.WinForms.TextBox txtPreImage;
		private System.WinForms.Button cmdHash;

        public MainForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

			cboAlgorithms.Items.Add("SHA1_CSP");
			cboAlgorithms.Items.Add("MD5_CSP");

			cboEncoding.Items.Add("Unicode");
			cboEncoding.Items.Add("ASCII");
		}

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.txtPreImage = new System.WinForms.TextBox ();
			this.txtHash = new System.WinForms.TextBox ();
			this.cboEncoding = new System.WinForms.ComboBox ();
			this.label2 = new System.WinForms.Label ();
			this.lblHashValue = new System.WinForms.Label ();
			this.cmdHash = new System.WinForms.Button ();
			this.lblHashLength = new System.WinForms.Label ();
			this.cboAlgorithms = new System.WinForms.ComboBox ();
			this.lblAlgorithm = new System.WinForms.Label ();
			this.lblEncoding = new System.WinForms.Label ();
			this.label1 = new System.WinForms.Label ();
			this.lblPreImage = new System.WinForms.Label ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			txtPreImage.Location = new System.Drawing.Point (8, 24);
			txtPreImage.TabIndex = 0;
			txtPreImage.Size = new System.Drawing.Size (296, 20);
			txtHash.Location = new System.Drawing.Point (8, 144);
			txtHash.ReadOnly = true;
			txtHash.Multiline = true;
			txtHash.TabIndex = 3;
			txtHash.TabStop = false;
			txtHash.Size = new System.Drawing.Size (296, 64);
			cboEncoding.Location = new System.Drawing.Point (160, 64);
			cboEncoding.Size = new System.Drawing.Size (144, 21);
			cboEncoding.Style = System.WinForms.ComboBoxStyle.DropDownList;
			cboEncoding.TabIndex = 2;
			label2.Location = new System.Drawing.Point (8, 216);
			label2.Text = "Hash Length:";
			label2.Size = new System.Drawing.Size (80, 16);
			label2.TabIndex = 13;
			lblHashValue.Location = new System.Drawing.Point (8, 128);
			lblHashValue.Text = "Hash Value:";
			lblHashValue.Size = new System.Drawing.Size (80, 16);
			lblHashValue.TabIndex = 4;
			cmdHash.Location = new System.Drawing.Point (8, 96);
			cmdHash.Size = new System.Drawing.Size (88, 24);
			cmdHash.TabIndex = 3;
			cmdHash.Text = "Hash";
			cmdHash.Click += new System.EventHandler (this.cmdHash_Click);
			lblHashLength.Location = new System.Drawing.Point (88, 216);
			lblHashLength.Size = new System.Drawing.Size (80, 16);
			lblHashLength.BorderStyle = System.WinForms.BorderStyle.Fixed3D;
			lblHashLength.TabIndex = 14;
			lblHashLength.TextAlign = System.WinForms.HorizontalAlignment.Right;
			cboAlgorithms.Location = new System.Drawing.Point (8, 64);
			cboAlgorithms.Size = new System.Drawing.Size (144, 21);
			cboAlgorithms.Style = System.WinForms.ComboBoxStyle.DropDownList;
			cboAlgorithms.TabIndex = 1;
			lblAlgorithm.Location = new System.Drawing.Point (8, 48);
			lblAlgorithm.Text = "Algorithm:";
			lblAlgorithm.Size = new System.Drawing.Size (80, 16);
			lblAlgorithm.TabIndex = 7;
			lblAlgorithm.Visible = false;
			lblEncoding.Location = new System.Drawing.Point (160, 48);
			lblEncoding.Text = "Encoding:";
			lblEncoding.Size = new System.Drawing.Size (80, 16);
			lblEncoding.TabIndex = 10;
			label1.Location = new System.Drawing.Point (8, 48);
			label1.Text = "Algorithm:";
			label1.Size = new System.Drawing.Size (80, 16);
			label1.TabIndex = 12;
			lblPreImage.Location = new System.Drawing.Point (8, 8);
			lblPreImage.Text = "Pre-Image:";
			lblPreImage.Size = new System.Drawing.Size (80, 16);
			lblPreImage.TabIndex = 8;
			this.Text = "Hash Testing";
			this.StartPosition = System.WinForms.FormStartPosition.CenterScreen;
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (312, 237);
			this.Click += new System.EventHandler (this.MainForm_Click);
			this.Controls.Add (this.lblHashLength);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.lblEncoding);
			this.Controls.Add (this.cboEncoding);
			this.Controls.Add (this.lblPreImage);
			this.Controls.Add (this.lblAlgorithm);
			this.Controls.Add (this.cboAlgorithms);
			this.Controls.Add (this.lblHashValue);
			this.Controls.Add (this.txtHash);
			this.Controls.Add (this.txtPreImage);
			this.Controls.Add (this.cmdHash);
		}

		protected void cmdHash_Click (object sender, System.EventArgs e)
		{
			//  Precondition:  "Zero out" the result values.
			this.txtHash.Text = "";
			this.lblHashLength.Text = "";

			//  Precondition:  A pre-image must be given.
			if(this.txtPreImage.Text.Length > 0)
			{
				//  Precondition:  The user must select a hash algorithm.
				if(this.cboAlgorithms.SelectedIndex > -1)
				{
					//  Precondition:  The user must select either Unicode or ASCII.
					if(this.cboEncoding.SelectedIndex > -1)
					{
						byte[] hashValue;
						byte[] result;
						HashAlgorithm hash;
						Type algType;
						ConstructorInfo algTypeConst;

						if(this.cboEncoding.Text == "ASCII")
						{
							hashValue = Encoding.ASCII.GetBytes(txtPreImage.Text);
						}
						else
						{
							hashValue = Encoding.Unicode.GetBytes(txtPreImage.Text);
						}

						//  Create the algorithm via reflection.
						algType = Type.GetType("System.Security.Cryptography." + 
							this.cboAlgorithms.Text);
						algTypeConst = algType.GetConstructor(new Type[0]);
						//hash = (HashAlgorithm)algTypeConst.Invoke(null);
						
						try
						{
							hash = SHA1.Create("SHA1")						
						}
						catch(CryptographicUnexpectedOperationException ce)
						{

						}

						hash.Write(hashValue);
						hash.CloseStream();
						result = hash.Hash;
						
						foreach(byte b in result)
						{
							this.txtHash.Text += "0x" + b.Format("x2", null).ToUpper() + " ";
						}

						this.lblHashLength.Text = result.Length.ToString();
					}
					else
					{
						MessageBox.Show("Please select the encoding type.", "Encoding Selection Error", 
									    MessageBox.OK | MessageBox.IconExclamation);
					}
				}
				else
				{
					MessageBox.Show("Please select the algorithm type.", "Algorithm Selection Error", 
									MessageBox.OK | MessageBox.IconExclamation);
				}
			}
			else
			{
				MessageBox.Show("Please enter a pre-image.", "Pre-Image Entry Error", 
								MessageBox.OK | MessageBox.IconExclamation);
			}
		}

		protected void MainForm_Click (object sender, System.EventArgs e)
		{

		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new MainForm());
        }
    }
}
