using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace KeyExchangeSample
{
	class KeyExchangeSampleTester
	{
		static void Main(string[] args)
		{
			try
			{
				RSACryptoServiceProvider bobKeyPair = new RSACryptoServiceProvider();
				RSACryptoServiceProvider aliceKeyPair = new RSACryptoServiceProvider();
				
				Rijndael bobKeyExch = new RijndaelManaged();
				bobKeyExch.KeySize = 128;
				bobKeyExch.GenerateKey();
				Console.WriteLine("Session key created - value is " + 
					ArrayToHexString(bobKeyExch.Key));

				RSAPKCS1KeyExchangeFormatter bobKeyFormatter = new RSAPKCS1KeyExchangeFormatter();
				RSACryptoServiceProvider alicePublicKey = new RSACryptoServiceProvider();
				alicePublicKey.FromXmlString(aliceKeyPair.ToXmlString(false));
				bobKeyFormatter.SetKey(alicePublicKey);
				byte[] bobKeyExchData = bobKeyFormatter.CreateKeyExchange(bobKeyExch.Key);

				Console.WriteLine("Key exchange data created - value is " + 
					ArrayToHexString(bobKeyExchData));

				RSACryptoServiceProvider alicePrivateKey = new RSACryptoServiceProvider();
				alicePrivateKey.FromXmlString(aliceKeyPair.ToXmlString(true));
				RSAPKCS1KeyExchangeDeformatter aliceKeyDeformatter = new RSAPKCS1KeyExchangeDeformatter();
				aliceKeyDeformatter.SetKey(alicePrivateKey);
				byte[] aliceKeyExchData = aliceKeyDeformatter.DecryptKeyExchange(bobKeyExchData);

				Console.WriteLine("Key exchange data transmitted - value is " + 
					ArrayToHexString(aliceKeyExchData));

				Rijndael aliceKeyExch = new RijndaelManaged();
				aliceKeyExch.KeySize = 128;
				aliceKeyExch.Key = aliceKeyExchData;
				Console.WriteLine("Session key transmitted - value is " + 
					ArrayToHexString(aliceKeyExch.Key));
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b.ToString("X2"));
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}	
	}
}

