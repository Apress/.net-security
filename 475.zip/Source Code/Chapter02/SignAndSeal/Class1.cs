using System;

namespace APress.SignAndSeal
{
	public sealed class SignedObject
	{
		public SignedObject() : base()
		{
		}
	}
}
