using System;

namespace SignAndSealClient
{
	[Serializable]
	public class SignAndSealTest
	{
		private String m_internalData = null;

		public SignAndSealTest(String data)
		{
			this.m_internalData = data;
		}
		public String getData()
		{
			return this.internalData;
		}
		public String setData(String data)
		{
			this.internalData = data;
		}
		public override String ToString()
		{
			return this.internalData;
		}
	}
}
