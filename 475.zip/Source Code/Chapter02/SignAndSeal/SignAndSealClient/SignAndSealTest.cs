using System;
using System.Runtime.Serialization;

namespace SignAndSealClient
{
	[Serializable]
	public class SignAndSealTest : ISerializable
	{
		private String m_internalData = null;

		private SignAndSealTest(SerializationInfo si, StreamingContext stc)
		{
			this.m_internalData = si.GetString("InternalData");
		}
		
		public SignAndSealTest(String data)
		{
			this.m_internalData = data;
		}

		public void GetObjectData(SerializationInfo si, StreamingContext stc)
		{
			si.AddValue("InternalData", this.m_internalData);
		}

		public String Data
		{
			get
			{
				return(this.m_internalData);
			}
			set
			{
				this.m_internalData = value;
			}
		}

		public override String ToString()
		{
			return this.m_internalData;
		}
	}
}
