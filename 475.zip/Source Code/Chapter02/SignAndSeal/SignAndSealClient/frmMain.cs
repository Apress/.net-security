using APress.SignAndSeal;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace SignAndSealClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnSignAndVerifyGood;
		private System.Windows.Forms.Button btnSealAndOpenGood;
		private System.Windows.Forms.Button btnThreePersonTest;
		private System.Windows.Forms.ListBox lstThreePersonStatus;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSealAndOpenGood = new System.Windows.Forms.Button();
			this.btnThreePersonTest = new System.Windows.Forms.Button();
			this.lstThreePersonStatus = new System.Windows.Forms.ListBox();
			this.btnSignAndVerifyGood = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnSealAndOpenGood
			// 
			this.btnSealAndOpenGood.Location = new System.Drawing.Point(8, 40);
			this.btnSealAndOpenGood.Name = "btnSealAndOpenGood";
			this.btnSealAndOpenGood.Size = new System.Drawing.Size(128, 24);
			this.btnSealAndOpenGood.TabIndex = 1;
			this.btnSealAndOpenGood.Text = "Seal and Open (Good)";
			this.btnSealAndOpenGood.Click += new System.EventHandler(this.btnSealAndOpenGood_Click);
			// 
			// btnThreePersonTest
			// 
			this.btnThreePersonTest.Location = new System.Drawing.Point(8, 72);
			this.btnThreePersonTest.Name = "btnThreePersonTest";
			this.btnThreePersonTest.Size = new System.Drawing.Size(128, 24);
			this.btnThreePersonTest.TabIndex = 2;
			this.btnThreePersonTest.Text = "Three-Person Test";
			this.btnThreePersonTest.Click += new System.EventHandler(this.btnThreePersonTest_Click);
			// 
			// lstThreePersonStatus
			// 
			this.lstThreePersonStatus.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lstThreePersonStatus.IntegralHeight = false;
			this.lstThreePersonStatus.Location = new System.Drawing.Point(8, 104);
			this.lstThreePersonStatus.Name = "lstThreePersonStatus";
			this.lstThreePersonStatus.Size = new System.Drawing.Size(280, 160);
			this.lstThreePersonStatus.TabIndex = 3;
			// 
			// btnSignAndVerifyGood
			// 
			this.btnSignAndVerifyGood.Location = new System.Drawing.Point(8, 8);
			this.btnSignAndVerifyGood.Name = "btnSignAndVerifyGood";
			this.btnSignAndVerifyGood.Size = new System.Drawing.Size(128, 24);
			this.btnSignAndVerifyGood.TabIndex = 0;
			this.btnSignAndVerifyGood.Text = "Sign and Verify (Good)";
			this.btnSignAndVerifyGood.Click += new System.EventHandler(this.btnSignAndVerifyGood_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lstThreePersonStatus,
																		  this.btnThreePersonTest,
																		  this.btnSealAndOpenGood,
																		  this.btnSignAndVerifyGood});
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SignAndSeal Test";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{

		}

		private void btnSignAndVerifyGood_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;

			SHA1 sha = new SHA1Managed();
			SignAndSealTest sasRSA = new SignAndSealTest("Sign and seal me, RSA!");
			
			RSASignedObject rsaSignedTest = new RSASignedObject(sasRSA);
			MemoryStream ms = new MemoryStream();
			IFormatter ifrm = new BinaryFormatter();
			ifrm.Serialize(ms, rsaSignedTest);
			ms.Position = 0;
			RSASignedObject rsaSignedTestBack = (RSASignedObject)ifrm.Deserialize(ms);

			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
			String rsaKeyValues = rsa.ToXmlString(true);
			RSASignedObject rsaSigned = new RSASignedObject(sasRSA);
			rsaSigned.Sign(rsaKeyValues, sha);

			DSACryptoServiceProvider dsa = new DSACryptoServiceProvider();
			String desKeyValues = dsa.ToXmlString(true);
			DSASignedObject dsaSigned = new DSASignedObject(rsaSigned);
			dsaSigned.Sign(desKeyValues);
			desKeyValues = dsa.ToXmlString(false);
			Cursor.Current = Cursors.Default;
			MessageBox.Show(dsaSigned.Verify(desKeyValues).ToString());
			Cursor.Current = Cursors.WaitCursor;
			
			RSASignedObject rsaSignedByDSA = (RSASignedObject)dsaSigned.InnerObject;
			rsaKeyValues = rsa.ToXmlString(false);
			MessageBox.Show(rsaSignedByDSA.Verify(rsaKeyValues).ToString());
			SignAndSealTest sasRSAVerified = (SignAndSealTest)rsaSignedByDSA.InnerObject;
			Cursor.Current = Cursors.Default;
			MessageBox.Show(sasRSAVerified.Data);
		}

		private void btnSealAndOpenGood_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;

			SignAndSealTest sasRSA = new SignAndSealTest("Seal and open me, RSA!");
			
			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
			String rsaPublicKeyValues = rsa.ToXmlString(false);
			RSASealedObject rsaSealed = new RSASealedObject(sasRSA);
			rsaSealed.Seal(rsaPublicKeyValues);

			try
			{
				SignAndSealTest sasBad = (SignAndSealTest)rsaSealed.InnerObject;
			}
			catch(Exception exc)
			{
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Exception:  " + exc.Message);
			}

			RSAParameters rsaParams = rsa.ExportParameters(true);
			rsaSealed.Open(rsaParams);
			SignAndSealTest sasRSAOpened = (SignAndSealTest)rsaSealed.InnerObject;
			Cursor.Current = Cursors.Default;
			MessageBox.Show(sasRSAOpened.Data);
		}

		private void btnThreePersonTest_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;

			this.lstThreePersonStatus.Items.Clear();
			this.lstThreePersonStatus.Items.Add("The original message is:  \"Joe's original data.\"");
			SignAndSealTest joesObject = new SignAndSealTest("Joe's original data.");
			DSACryptoServiceProvider joesKeys = new DSACryptoServiceProvider();
			DSASignedObject joesSig = new DSASignedObject(joesObject);
			DSAParameters joesPrivateKey = joesKeys.ExportParameters(true);
			this.lstThreePersonStatus.Items.Add("Joe's signing the object...");
			this.Refresh();
			joesSig.Sign(joesPrivateKey);
			this.lstThreePersonStatus.Items.Add("Joe's signing is done.");
			this.Refresh();

			RSACryptoServiceProvider stevesKeys = new RSACryptoServiceProvider();
			RSASignedObject stevesSig = new RSASignedObject(joesSig);
			RSAParameters stevesPrivateKey = stevesKeys.ExportParameters(true);
			this.lstThreePersonStatus.Items.Add("Steve's signing the object...");
			this.Refresh();
			stevesSig.Sign(stevesPrivateKey, new SHA1Managed());
			this.lstThreePersonStatus.Items.Add("Steve's signing is done.");
			this.Refresh();

			RSACryptoServiceProvider carolsKeys = new RSACryptoServiceProvider();
			String carolsPublicKey = carolsKeys.ToXmlString(false);
			RSASealedObject carolsLock = new RSASealedObject(stevesSig);
			this.lstThreePersonStatus.Items.Add("Steve's sealing the object...");
			this.Refresh();
			carolsLock.Seal(carolsPublicKey);
			this.lstThreePersonStatus.Items.Add("Steve's sealing is done.");
			this.Refresh();

			MemoryStream ms = new MemoryStream();
			IFormatter ifrm = new BinaryFormatter();
			this.lstThreePersonStatus.Items.Add("Steve's serializing the contents...");
			this.Refresh();
			ifrm.Serialize(ms, carolsLock);
			this.lstThreePersonStatus.Items.Add("Steve's serializing is done.");
			this.Refresh();
			
			ms.Position = 0;

			this.lstThreePersonStatus.Items.Add("Carol's deserializing the object...");
			this.Refresh();
			RSASealedObject carolsUnlock = (RSASealedObject)ifrm.Deserialize(ms);
			this.lstThreePersonStatus.Items.Add("Carol's deserializing is done.");
			this.Refresh();
			ms.Close();
			RSAParameters carolsPrivateKey = carolsKeys.ExportParameters(true);
			this.lstThreePersonStatus.Items.Add("Carol's opening the object...");
			this.Refresh();
			carolsUnlock.Open(carolsPrivateKey);
			this.lstThreePersonStatus.Items.Add("Carol's opened the object.");
			this.Refresh();

			RSASignedObject stevesVerify = (RSASignedObject)carolsUnlock.InnerObject;
			String stevesPublicKey = stevesKeys.ToXmlString(false);
			this.lstThreePersonStatus.Items.Add("Carol's verifying Steve's sig...");
			this.Refresh();
			bool isSteveOK = stevesVerify.Verify(stevesPublicKey);

			if(true == isSteveOK)
			{
				this.lstThreePersonStatus.Items.Add("Carol verified Steve's sig.");
				this.Refresh();
				DSASignedObject joesVerify = (DSASignedObject)stevesVerify.InnerObject;
				DSAParameters joesPublicKey = joesKeys.ExportParameters(false);
				this.lstThreePersonStatus.Items.Add("Carol's verifying Joe's sig...");
				this.Refresh();
				bool isJoeOK = joesVerify.Verify(joesPublicKey);
				if(true == isJoeOK)
				{
					this.lstThreePersonStatus.Items.Add("Carol verified Joe's sig.");
					this.Refresh();
					SignAndSealTest joesOriginal = (SignAndSealTest)joesVerify.InnerObject;
					this.lstThreePersonStatus.Items.Add("Message is:  " + joesOriginal.Data);
					this.Refresh();
				}
				else
				{
					this.lstThreePersonStatus.Items.Add("Carol did NOT verify Joe's sig.");
					this.Refresh();
				}
			}
			else
			{
				this.lstThreePersonStatus.Items.Add("Carol did NOT verify Steve's sig.");
				this.Refresh();
			}

			Cursor.Current = Cursors.Default;
		}
	}
}
