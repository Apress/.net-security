using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace APress.DotNetSecurity.Chapter2.SignaturesSample
{
	class SignaturesSampleTester
	{
		static void Main(string[] args)
		{
			try
			{
				byte[] someData = {56,34,25,61,55,20,90,50,44};
				Console.WriteLine("Base data is " + ArrayToHexString(someData));
				RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
				RSACryptoServiceProvider rsaSign = new RSACryptoServiceProvider();
				RSACryptoServiceProvider rsaVerify = new RSACryptoServiceProvider();
				SHA1 sha = new SHA1Managed();
				rsaSign.FromXmlString(rsa.ToXmlString(true));
				byte[] sig = rsaSign.SignData(someData, sha);
				Console.WriteLine("RSA signed data (via SignData()) is " + 
					ArrayToHexString(sig));
				rsaVerify.FromXmlString(rsa.ToXmlString(false));
				bool isValid = rsaVerify.VerifyData(someData, 
					sha, sig);
				Console.WriteLine("Is the RSA signature valid (via VerifyData())?  " + 
					isValid.ToString());

				Console.WriteLine();
				DSACryptoServiceProvider dsaKey = new DSACryptoServiceProvider();
				DSASignatureFormatter dsaSigForm = new DSASignatureFormatter();
				dsaSigForm.SetKey(dsaKey);
				byte[] dsaSignature = dsaSigForm.CreateSignature(sha.ComputeHash(someData));
				Console.WriteLine("DSA signed data (via CreateSignature()) is " + 
					ArrayToHexString(dsaSignature));
				DSASignatureDeformatter dsaSigDeform = new DSASignatureDeformatter(dsaKey);
				isValid = dsaSigDeform.VerifySignature(sha.ComputeHash(someData), 
					dsaSignature);
				Console.WriteLine("Is the DSA signature valid (via VerifySignature())?  " + 
					isValid.ToString());
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b.ToString("X2"));
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}	
	}
}

