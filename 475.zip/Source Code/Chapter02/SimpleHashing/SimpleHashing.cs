using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace APress.DotNetSecurity.Chapter2.SimpleHashing
{
	class SimpleHashingTester
	{
		static void Main(string[] args)
		{
			try
			{
				String originalPreImage = "The quick brown fox jumped over the lazy dog.";
				Console.WriteLine("Getting the byte data for \"" + originalPreImage + "\"");
				byte[] preImage = Encoding.Unicode.GetBytes(originalPreImage);
				Console.WriteLine("Encoding is complete - array data is " + 
					ArrayToHexString(preImage));
				
				Console.WriteLine("Setting up the memory streams...");
				MemoryStream msIn = new MemoryStream(preImage);
				MemoryStream msOut = new MemoryStream();

				Console.WriteLine("Creating the hash algorithm...");
				SHA512 sha = new SHA512Managed();
				CryptoStream csSHA = new CryptoStream(msIn, 
					sha, CryptoStreamMode.Read);

				Console.WriteLine("Hashing the pre-image...");
				byte[] inData = new byte[msIn.Length];
				csSHA.Read(inData, 0, (int)msIn.Length);
				msOut.Write(sha.Hash, 0, (int)sha.Hash.Length);
				byte[] hashData = new byte[msOut.Length];
				Array.Copy(msOut.GetBuffer(), 0, hashData, 0, (int)msOut.Length);
				Console.WriteLine("Hash is done - array data is " + 
					ArrayToHexString(hashData));

			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}

		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b.ToString("X2"));
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}
	}
}
