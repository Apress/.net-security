using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace APress.DotNetSecurity.Chapter2.SymmetricAlgorithmEncryptor
{
	class SymmetricAlgorithmEncryptorTester
	{
		static void Main(string[] args)
		{
			try
			{
				String adPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				Console.WriteLine("Creating the random data file information...");
				RandomNumberGenerator rng = new RNGCryptoServiceProvider();
				byte[] randomBytes = new byte[1000];
				rng.GetNonZeroBytes(randomBytes);

				FileStream fCreate = new FileStream(adPath + @"\randomData.dat", 
					FileMode.Create, FileAccess.Write);

				Console.WriteLine("Writing the random data to the file " + 
					adPath + @"\randomData.dat...");
				fCreate.Write(randomBytes, 0, (int)randomBytes.Length);
				fCreate.Close();

				FileStream fin = new FileStream(adPath + @"\randomData.dat", 
					FileMode.Open, FileAccess.Read);
				MemoryStream mout = new MemoryStream();
				byte[] finData = new byte[fin.Length];
 
				SymmetricAlgorithm rijn = Rijndael.Create();
				CryptoStream coutenc = new CryptoStream(mout, rijn.CreateEncryptor(), 
					CryptoStreamMode.Write);
				Console.WriteLine("Encrypting the random data...");
				fin.Read(finData, 0, (int)fin.Length);
				coutenc.Write(finData, 0, (int)fin.Length);
				coutenc.FlushFinalBlock();

				FileStream fdec = new FileStream(adPath + @"\randomDataMirror.dat", 
					FileMode.Create, FileAccess.Write);

				CryptoStream coutdec = new CryptoStream(fdec, rijn.CreateDecryptor(), 
					CryptoStreamMode.Write);
				Console.WriteLine("Decrypting the random data and writing to " +
					adPath + @"\randomDataMirror.dat...");
				coutdec.Write(mout.GetBuffer(), 0, (int)(mout.Length));
				coutdec.Close();
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b.ToString("X2"));
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}	
	}
}

