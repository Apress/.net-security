using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace X509Info
{
	class X509InfoTester
	{
		static void Main(string[] args)
		{
			try
			{
				String adPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				X509Certificate x509 = X509Certificate.CreateFromCertFile(
					adPath + @"\simpleCert.cer");
				String x509Name = x509.GetName();
				Console.WriteLine("Name:  " + x509.GetName());
				Console.WriteLine("Effective Date:  " + x509.GetEffectiveDateString());
				Console.WriteLine("Expiration Date:  " + x509.GetExpirationDateString());
				Console.WriteLine("Issuer Name:  " + x509.GetIssuerName());
				Console.WriteLine("Key Algorithm:  " + x509.GetKeyAlgorithm());
				Console.WriteLine("Key Algorithm Parameters:  " + 
					x509.GetKeyAlgorithmParametersString());
				Console.WriteLine("Public Key:  " + x509.GetPublicKeyString());
				Console.WriteLine("Format :  " + x509.GetFormat());
				Console.WriteLine("Serial Number:  " + x509.GetSerialNumberString());
			}
			catch(CryptographicUnexpectedOperationException cuoe) 
			{
				Console.WriteLine("CryptographicUnexpectedOperationException:  " 
					+ cuoe.Message);
				Console.WriteLine(cuoe.StackTrace);
			}
			catch(CryptographicException ce) 
			{
				Console.WriteLine("CryptographicException:  " + ce.Message);
				Console.WriteLine(ce.StackTrace);
			}
			catch(Exception ge) 
			{
				Console.WriteLine("Exception:  " + ge.GetType().Name + " " + ge.Message);
				Console.WriteLine(ge.StackTrace);
			}
			finally
			{
				Console.WriteLine("Press the return key to continue...");
				Console.Read();
			}
		}
		private static String ArrayToHexString(byte[] ByteData)
		{
			StringBuilder retVal = new StringBuilder();
			
			foreach(byte b in ByteData)
			{
				retVal.Append(b);
				retVal.Append(" ");
			}
			retVal.Remove(retVal.Length - 1, 1);

			return retVal.ToString();
		}	
	}
}
