using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;

namespace APress.DotNetSecurity.Chapter3.XMLEncryptionTest
{
	public class frmMain : System.Windows.Forms.Form
	{
		private Rijndael rKey = new RijndaelManaged();
		private RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();

		private System.Windows.Forms.Label lblKeyExchange;
		private System.Windows.Forms.TextBox txtKeyExchange;
		private System.Windows.Forms.Label lblEncryptedElement;
		private System.Windows.Forms.TextBox txtEncryptedElement;
		private System.Windows.Forms.Button btnKeyExchange;
		private System.Windows.Forms.Button btnEncryption;
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtKeyExchange = new System.Windows.Forms.TextBox();
			this.btnKeyExchange = new System.Windows.Forms.Button();
			this.lblKeyExchange = new System.Windows.Forms.Label();
			this.lblEncryptedElement = new System.Windows.Forms.Label();
			this.txtEncryptedElement = new System.Windows.Forms.TextBox();
			this.btnEncryption = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtKeyExchange
			// 
			this.txtKeyExchange.Location = new System.Drawing.Point(8, 56);
			this.txtKeyExchange.Multiline = true;
			this.txtKeyExchange.Name = "txtKeyExchange";
			this.txtKeyExchange.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtKeyExchange.Size = new System.Drawing.Size(280, 96);
			this.txtKeyExchange.TabIndex = 2;
			this.txtKeyExchange.Text = "";
			// 
			// btnKeyExchange
			// 
			this.btnKeyExchange.Location = new System.Drawing.Point(8, 8);
			this.btnKeyExchange.Name = "btnKeyExchange";
			this.btnKeyExchange.Size = new System.Drawing.Size(112, 24);
			this.btnKeyExchange.TabIndex = 0;
			this.btnKeyExchange.Text = "Key Exchange";
			this.btnKeyExchange.Click += new System.EventHandler(this.btnKeyExchange_Click);
			// 
			// lblKeyExchange
			// 
			this.lblKeyExchange.Location = new System.Drawing.Point(8, 40);
			this.lblKeyExchange.Name = "lblKeyExchange";
			this.lblKeyExchange.Size = new System.Drawing.Size(112, 16);
			this.lblKeyExchange.TabIndex = 1;
			this.lblKeyExchange.Text = "Key Exchange";
			// 
			// lblEncryptedElement
			// 
			this.lblEncryptedElement.Location = new System.Drawing.Point(8, 160);
			this.lblEncryptedElement.Name = "lblEncryptedElement";
			this.lblEncryptedElement.Size = new System.Drawing.Size(112, 16);
			this.lblEncryptedElement.TabIndex = 1;
			this.lblEncryptedElement.Text = "EncryptedElement";
			// 
			// txtEncryptedElement
			// 
			this.txtEncryptedElement.Location = new System.Drawing.Point(8, 184);
			this.txtEncryptedElement.Multiline = true;
			this.txtEncryptedElement.Name = "txtEncryptedElement";
			this.txtEncryptedElement.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtEncryptedElement.Size = new System.Drawing.Size(280, 112);
			this.txtEncryptedElement.TabIndex = 2;
			this.txtEncryptedElement.Text = "";
			// 
			// btnEncryption
			// 
			this.btnEncryption.Location = new System.Drawing.Point(136, 8);
			this.btnEncryption.Name = "btnEncryption";
			this.btnEncryption.Size = new System.Drawing.Size(120, 24);
			this.btnEncryption.TabIndex = 3;
			this.btnEncryption.Text = "Encryption";
			this.btnEncryption.Click += new System.EventHandler(this.btnEncryption_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 301);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnEncryption,
																		  this.lblEncryptedElement,
																		  this.txtEncryptedElement,
																		  this.txtKeyExchange,
																		  this.lblKeyExchange,
																		  this.btnKeyExchange});
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Xml Encryption Test";
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void btnKeyExchange_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.txtKeyExchange.Text = null;
				MemoryStream encryptedData = new MemoryStream();

				int start = 0;
				do
				{
					byte[] keyMaterial = new byte[16];
					Array.Copy(rKey.Key, start, keyMaterial, 0, 16);
					byte[] encryptedSessionKey = rsa.Encrypt(keyMaterial, false);
					encryptedData.Write(encryptedSessionKey, 0, 
						(int)encryptedSessionKey.Length);
					start += 16;
				} while(start < rKey.Key.Length);

				encryptedData.Position = 0;
				String rToBase64 = Convert.ToBase64String(encryptedData.GetBuffer(), 
					0, (int)encryptedData.Length);

				XmlDocument keyExchDoc = new XmlDocument();
				XmlElement encryptedKey = keyExchDoc.CreateElement("EncryptedKey");
				keyExchDoc.AppendChild(encryptedKey);
				XmlAttribute carriedKeyName = keyExchDoc.CreateAttribute("CarriedKeyName");
				carriedKeyName.Value = "Jane's Session Key";
				encryptedKey.Attributes.Append(carriedKeyName);

				XmlElement encryptionMethod = keyExchDoc.CreateElement("EncryptionMethod");
				encryptedKey.AppendChild(encryptionMethod);
				XmlAttribute encryptionAlgorithm = keyExchDoc.CreateAttribute("Algorithm");
				encryptionAlgorithm.Value = "http://www.w3.org/2001/04/xmlenc#rsa-1_5";
				encryptionMethod.Attributes.Append(encryptionAlgorithm);

				XmlElement keyInfo = keyExchDoc.CreateElement("ds", "KeyInfo", 
					"http://www.w3.org/2000/09/xmldsig#");
				encryptedKey.AppendChild(keyInfo);

				XmlElement keyName = keyExchDoc.CreateElement("ds", "KeyName", null);
				keyName.InnerText = "Jane's Private Key";
				keyInfo.AppendChild(keyName);

				XmlElement cipherData = keyExchDoc.CreateElement("CipherData");
				encryptedKey.AppendChild(cipherData);

				XmlElement cipherValue = keyExchDoc.CreateElement("CipherValue");
				cipherValue.InnerText = rToBase64;
				cipherData.AppendChild(cipherValue);

				this.txtKeyExchange.Text = keyExchDoc.OuterXml;
			}
			catch(Exception ex)
			{
				MessageBox.Show("Exception:  " + ex.Message + ex.StackTrace);
			}
		}

		private void btnEncryption_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.txtEncryptedElement.Text = null;

				//  Load the XML document.
				String appPath = Application.StartupPath;
				XmlDocument paymentDoc = new XmlDocument();
				paymentDoc.Load(appPath + @"\Order.XML");
				XmlElement paymentElem = (XmlElement)paymentDoc.SelectSingleNode("Order/Payment");

				//  Encrypt the payment information.
				byte[] paymentXmlInfo = Encoding.Unicode.GetBytes(paymentElem.OuterXml);
				MemoryStream ms = new MemoryStream();
				CryptoStream csBase64 = new CryptoStream(ms, 
					new ToBase64Transform(), 
					CryptoStreamMode.Write);
				CryptoStream csRijndael = new CryptoStream(csBase64, 
					rKey.CreateEncryptor(), 
					CryptoStreamMode.Write);
				csRijndael.Write(paymentXmlInfo, 0, 
					(int)paymentXmlInfo.Length);
				csRijndael.FlushFinalBlock();
				String base64enc = Encoding.ASCII.GetString(ms.GetBuffer(),
					0, (int)ms.Length);

				//  Create the encryption-related elements.
				XmlElement encryptedData = paymentDoc.CreateElement("EncryptedData");
				XmlAttribute encryptedType = paymentDoc.CreateAttribute("Type");
				encryptedType.Value = "http://www.w3.org/2001/04/xmlenc#Element";
				encryptedData.Attributes.Append(encryptedType);

				XmlElement keyInfo = paymentDoc.CreateElement("ds", "KeyInfo", 
					"http://www.w3.org/2000/09/xmldsig#");
				encryptedData.AppendChild(keyInfo);

				XmlElement keyName = paymentDoc.CreateElement("ds", "KeyName", null);
				keyName.InnerText = "Jane's Session Key";
				keyInfo.AppendChild(keyName);

				XmlElement cipherData = paymentDoc.CreateElement("CipherData");
				encryptedData.AppendChild(cipherData);

				XmlElement cipherValue = paymentDoc.CreateElement("CipherValue");
				cipherValue.InnerText = base64enc;
				cipherData.AppendChild(cipherValue);

				XmlElement orderElem = (XmlElement)paymentDoc.SelectSingleNode("Order");
				
				//  Remove the Payment element, and replace it
				//  with the encryption elements.
				orderElem.ReplaceChild(encryptedData, paymentElem);
				this.txtEncryptedElement.Text = paymentDoc.OuterXml;

				//  Now reverse the process.  Load the XML doc with the 
				//  encryption information.
				XmlDocument docToDecrypt = new XmlDocument();
				docToDecrypt.LoadXml(orderElem.OuterXml);

				//  Find the EncryptedData element.
				XmlElement encryptedElem = 
					(XmlElement)docToDecrypt.SelectSingleNode("Order/EncryptedData");

				//  We should "look up" the key info,
				//  but we already have it.
				//  Get the ciphered data, Base-64 it,
				//  and decrypt it.
				XmlElement cipherDataElem = 
					(XmlElement)encryptedElem.SelectSingleNode("CipherData/CipherValue");

				byte[] cipherDataRes = Convert.FromBase64String(cipherDataElem.InnerText);

				MemoryStream msDec = new MemoryStream();
				CryptoStream csRijndaelDec = new CryptoStream(msDec, 
					rKey.CreateDecryptor(), 
					CryptoStreamMode.Write);
				csRijndaelDec.Write(cipherDataRes, 0, 
					(int)cipherDataRes.Length);
				csRijndaelDec.FlushFinalBlock();
				String finalResult = Encoding.Unicode.GetString(msDec.GetBuffer(),
					0, (int)msDec.Length);

				//  Now replace the EncryptedData OuterXml
				//  with the decrypted information.
				XmlNode encryptedParentElem = encryptedElem.ParentNode;
				XmlDocumentFragment xdf = docToDecrypt.CreateDocumentFragment();
				xdf.InnerXml = finalResult;
				encryptedParentElem.ReplaceChild(xdf, encryptedElem);
				MessageBox.Show(docToDecrypt.OuterXml);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Exception:  " + ex.Message + ex.StackTrace);
			}
		}
	}
}
