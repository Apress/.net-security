using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;

namespace APress.DotNetSecurity.Chapter3.XMLSignaturesTest
{
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnSign;
		private System.Windows.Forms.Label lblResults;
		private System.Windows.Forms.TextBox txtResults;
		private System.Windows.Forms.Button btnSignDoc;
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblResults = new System.Windows.Forms.Label();
			this.btnSign = new System.Windows.Forms.Button();
			this.txtResults = new System.Windows.Forms.TextBox();
			this.btnSignDoc = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblResults
			// 
			this.lblResults.Location = new System.Drawing.Point(8, 48);
			this.lblResults.Name = "lblResults";
			this.lblResults.Size = new System.Drawing.Size(96, 16);
			this.lblResults.TabIndex = 2;
			this.lblResults.Text = "Results:";
			// 
			// btnSign
			// 
			this.btnSign.Location = new System.Drawing.Point(8, 16);
			this.btnSign.Name = "btnSign";
			this.btnSign.Size = new System.Drawing.Size(104, 24);
			this.btnSign.TabIndex = 0;
			this.btnSign.Text = "Sign &Element";
			this.btnSign.Click += new System.EventHandler(this.btnSign_Click);
			// 
			// txtResults
			// 
			this.txtResults.Location = new System.Drawing.Point(8, 64);
			this.txtResults.Multiline = true;
			this.txtResults.Name = "txtResults";
			this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtResults.Size = new System.Drawing.Size(280, 392);
			this.txtResults.TabIndex = 3;
			this.txtResults.Text = "";
			// 
			// btnSignDoc
			// 
			this.btnSignDoc.Location = new System.Drawing.Point(120, 16);
			this.btnSignDoc.Name = "btnSignDoc";
			this.btnSignDoc.Size = new System.Drawing.Size(104, 24);
			this.btnSignDoc.TabIndex = 1;
			this.btnSignDoc.Text = "Sign &Document";
			this.btnSignDoc.Click += new System.EventHandler(this.btnSignDoc_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 469);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnSignDoc,
																		  this.txtResults,
																		  this.lblResults,
																		  this.btnSign});
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Signatures Test";
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void btnSign_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.txtResults.Text = null;

				//  Load the XML file.
				String appPath = Application.StartupPath;
				XmlDocument xmlDoc = new XmlDocument();
				xmlDoc.Load(appPath + @"\Order.XML");
				XmlNodeList paymentElems = xmlDoc.SelectNodes("Order/Payment");

				//  Create the signature.
				SignedXml signedXml = new SignedXml();
				System.Security.Cryptography.Xml.DataObject paymentInfo = 
					new System.Security.Cryptography.Xml.DataObject();
				paymentInfo.Data = paymentElems;
				paymentInfo.Id = "OrderPayment";
				signedXml.AddObject(paymentInfo);
				Reference reference = new Reference();
				reference.Uri = "#OrderPayment";
				signedXml.AddReference(reference);
				RSA rsaKey = RSA.Create();
				signedXml.SigningKey = rsaKey; 
				KeyInfo keyInfo = new KeyInfo();
				keyInfo.AddClause(new RSAKeyValue(rsaKey));
				signedXml.KeyInfo = keyInfo;
				signedXml.ComputeSignature();

				//  Add this signature to the document
				xmlDoc.DocumentElement.InsertAfter(xmlDoc.ImportNode(signedXml.GetXml(), true), 
					xmlDoc.DocumentElement.FirstChild);
				this.txtResults.Text = xmlDoc.OuterXml;

				//  Verify the signature.
				XmlDocument signedDoc = new XmlDocument();
				signedDoc.LoadXml(xmlDoc.OuterXml);
				SignedXml sigs = new SignedXml(signedDoc);
				XmlNodeList sigElems = signedDoc.GetElementsByTagName("Signature");
				sigs.LoadXml((XmlElement)sigElems[0]);
				MessageBox.Show(sigs.CheckSignature().ToString());
			}
			catch(Exception ex)
			{
				MessageBox.Show("Exception:  " + ex.Message + ex.StackTrace);
			}
		}

		private void btnSignDoc_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.txtResults.Text = null;

				//  Create the signature.
				SignedXml signedXml = new SignedXml();
				Reference reference = new Reference();
				reference.Uri = @"file://" + Application.StartupPath + 
					@"\Order.XML";
				signedXml.AddReference(reference);
				RSA rsaKey = RSA.Create();
				signedXml.SigningKey = rsaKey; 
				KeyInfo keyInfo = new KeyInfo();
				keyInfo.AddClause(new RSAKeyValue(rsaKey));
				signedXml.KeyInfo = keyInfo;
				signedXml.ComputeSignature();

				//  Add this signature to the document
				this.txtResults.Text = signedXml.GetXml().OuterXml;

				//  Verify the signature.
				XmlDocument signedDoc = new XmlDocument();
				signedDoc.LoadXml(signedXml.GetXml().OuterXml);
				SignedXml sigs = new SignedXml(signedDoc);
				XmlNodeList sigElems = signedDoc.GetElementsByTagName("Signature");
				sigs.LoadXml((XmlElement)sigElems[0]);
				MessageBox.Show(sigs.CheckSignature().ToString());
			}
			catch(Exception ex)
			{
				MessageBox.Show("Exception:  " + ex.Message + ex.StackTrace);
			}
		
		}
	}
}
