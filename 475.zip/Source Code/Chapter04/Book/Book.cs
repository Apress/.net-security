using System;
using System.Collections;
using System.Security.Policy;
using System.Reflection;

namespace BookImpl
{
    public class Book : MarshalByRefObject
    {
        private string m_Author = null;
        private string m_Title = null;

        public Book() : base() {}

        public Book(string Author, string Title)
        {
            this.m_Author = Author;
            this.m_Title = Title;
			
			Console.WriteLine("Current AppDomain Name:  " + 
				AppDomain.CurrentDomain.FriendlyName);		
			
			IEnumerator adEvidence = AppDomain.CurrentDomain.Evidence.GetEnumerator();
            while(adEvidence.MoveNext())
            {
                object adevid = adEvidence.Current;
                Console.WriteLine("AppDomain Evidence:  " + adevid.ToString());
            }

            IEnumerator assemblyEvidence = 
                Assembly.GetExecutingAssembly().Evidence.GetEnumerator();
            while(assemblyEvidence.MoveNext())
            {
                object assemblyevid = assemblyEvidence.Current;
                Console.WriteLine("Assembly Evidence:  " + 
                    assemblyevid.ToString());
            }
        }

        public string Author
        {
            get
            { return this.m_Author; }
            set
            { this.m_Author = value; }
        }

        public string Title
        {
            get
            { return this.m_Title; }
            set
            { this.m_Title = Title; }
        }
    }
}
