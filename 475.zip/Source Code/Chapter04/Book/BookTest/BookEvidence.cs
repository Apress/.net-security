using System;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Security.Permissions;
using System.Security.Policy;
using BookImpl;

namespace EvidenceTest
{
    class ETest
    {
        static void Main(string[] args)
        {
            try
            {
                X509Certificate x = 
                    X509Certificate.CreateFromCertFile(
                    @"C:\assembly\simpleCert.cer");
                Publisher p = new Publisher(x);
                Url u = new Url(@"file:///C:/assembly");
                Zone z = new Zone(SecurityZone.MyComputer);
                object[] e = {p, u, z};
                Evidence eSet = new Evidence(e, null);
                AppDomain newAD = AppDomain.CreateDomain(
                    "ApressDomain", eSet, 
                    @"C:\assembly", null, false);
				
                IEnumerator es = newAD.Evidence.GetEnumerator();
                while(es.MoveNext())
                {
                    object evid = es.Current;
                    Console.WriteLine("Evidence:  " + 
                        evid.ToString());
                }
				
                string[] ctorArgs = {"Jason Bock", "Some Book"};

                AssemblyName bookAssemblyName = 
                    AssemblyName.GetAssemblyName(
                    @"C:\assembly\Book.dll");

				/*
				Assembly bookAssembly = newAD.Load(
					bookAssemblyName, eSet);
				Book aBook = bookAssembly.CreateInstance(
					"BookImpl.Book", false, 
					BindingFlags.CreateInstance, 
					null, ctorArgs, null, null) as Book;
				*/
				
                ObjectHandle aBookOH = newAD.CreateInstance(
                    bookAssemblyName.Name, "BookImpl.Book", 
                    false, BindingFlags.CreateInstance, 
                    null, ctorArgs, null,
                    null, eSet);

                Book aBook = aBookOH.Unwrap() as Book;
				
                Console.WriteLine("Author is " + aBook.Author);
                Console.WriteLine("Title is " + aBook.Title);
            }
            catch(Exception ge) 
            {
                Console.WriteLine("Exception:  " + 
                    ge.GetType().Name + " " + ge.Message);
                Console.WriteLine(ge.StackTrace);
            }
            finally
            {
                Console.WriteLine("Press the return key to continue...");
                Console.Read();
            }
        }
    }
}

