using System;
using System.Security;
using System.Security.Permissions;
//using Apress.Chapter4.CP;

namespace Apress.Chapter4.CP
{
	public class Customer
	{
		protected string m_FirstName = null;
		protected int m_ID = 0;
		protected string m_LastName = null;

		public Customer() : base() {}

		[method: CustomerPermissionAttribute(SecurityAction.Demand, Flags=CustomerPermissionFlag.ObjectCreation)]
		public Customer(string FirstName, string LastName, int ID)
		{
			this.m_FirstName = FirstName;
			this.m_LastName = LastName;
			this.m_ID = ID;
		}

		public string FirstName
		{
			get { return this.m_FirstName; }
			set { this.m_FirstName = value; }
		}

		public string LastName
		{
			get { return this.m_LastName; }
			set { this.m_LastName = value; }
		}

		public int ID
		{
			get { return this.m_ID; }
			[method: CustomerPermissionAttribute(SecurityAction.Demand, Flags=CustomerPermissionFlag.AllAccess)]
			set { this.m_ID = value; }
		}
	}
}
