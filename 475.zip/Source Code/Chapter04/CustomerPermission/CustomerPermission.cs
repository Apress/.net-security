using System;
using System.Security;
using System.Security.Permissions;
using System.Text;

[assembly:AllowPartiallyTrustedCallers]

namespace Apress.Chapter4.CP
{
	public enum CustomerPermissionFlag
	{
		NoAccess = 0, ObjectCreation = 1, AllAccess = 15
	};

	[AttributeUsageAttribute(AttributeTargets.All, AllowMultiple = true, Inherited = false)]
	public sealed class CustomerPermissionAttribute : CodeAccessSecurityAttribute
	{
		private CustomerPermissionFlag m_flags = CustomerPermissionFlag.NoAccess;

		public CustomerPermissionAttribute(SecurityAction action) : base(action) {}

		public override IPermission CreatePermission()
		{
			return new CustomerPermission(this.m_flags);
		}

		public CustomerPermissionFlag Flags
		{
			get{ return this.m_flags; }
			set{ this.m_flags = value; }
		}
	}

	public sealed class CustomerPermission : CodeAccessPermission, IUnrestrictedPermission
	{
		private const string ATTRIBUTE_CLASS = "class";
		private const string ATTRIBUTE_VERSION = "Version";
		private const string ELEMENT_FLAGS = "Flags";
		private const string ELEMENT_IPERMISSION = "IPermission";
		private const string ELEMENT_UNRESTRICTED = "Unrestricted";
		private const string ERROR_WRONG_ARGUMENT = "The given argument is not the correct type.";
		private const string VERSION = "1";
		private CustomerPermissionFlag m_flags = CustomerPermissionFlag.NoAccess;

		public CustomerPermission(PermissionState State) : base()
		{
			SetUnrestricted(State);
		}

		public CustomerPermission(CustomerPermissionFlag Flag) : base()
		{
			this.m_flags = Flag;
		}

		public override IPermission Copy()
		{
			return new CustomerPermission(this.m_flags);
		}

		public override IPermission Intersect(IPermission target)
		{
			IPermission retVal = null;
			CustomerPermission customerTarget = null;

			if(null != target)
			{
				customerTarget = target as CustomerPermission;

				if(null != customerTarget)
				{
					if(customerTarget.IsUnrestricted())
					{
						retVal = this.Copy();
					}
					else if(this.IsUnrestricted())
					{
						retVal = customerTarget.Copy();
					}
					else
					{
						retVal = new CustomerPermission(customerTarget.m_flags & this.m_flags);
					}
				}
				else
				{
					throw new ArgumentException(ERROR_WRONG_ARGUMENT, "target");
				}	
			}

			return retVal;
		}

		public override bool IsSubsetOf(IPermission target)
		{
			CustomerPermission cp = null;
			bool retVal = false;

			if(null == target)
			{
				if(CustomerPermissionFlag.NoAccess == this.m_flags)
				{
					retVal = true;
				}
			}
			else
			{
				cp = target as CustomerPermission;

				if(null != cp)
				{
					if(true == cp.IsUnrestricted())
					{
						retVal = true;
					}
					else if(true == this.IsUnrestricted())
					{
						retVal = false;
					}
					else
					{
						if(this.m_flags <= cp.m_flags)
						{
							retVal = true;
						}
					}
				}
				else
				{
					throw new ArgumentException(ERROR_WRONG_ARGUMENT, "target");
				}
			}

			return retVal;
		}

		public override void FromXml(SecurityElement PassedElement)
		{
			string elementRestrict = PassedElement.Attribute(ELEMENT_UNRESTRICTED);

			if(null != elementRestrict)
			{
				this.SetUnrestricted(Convert.ToBoolean(elementRestrict));
			}

			string elementFlags = PassedElement.Attribute(ELEMENT_FLAGS);

			if(null != elementFlags)
			{  
				this.m_flags = (CustomerPermissionFlag)Enum.Parse(typeof(CustomerPermissionFlag), elementFlags);
			}
		}

		public override SecurityElement ToXml()
		{
			SecurityElement element = new SecurityElement(ELEMENT_IPERMISSION);
			element.AddAttribute(ATTRIBUTE_CLASS, this.GetType().AssemblyQualifiedName);
			element.AddAttribute(ATTRIBUTE_VERSION, VERSION);

			if(true == this.IsUnrestricted())
			{
				element.AddAttribute(ELEMENT_UNRESTRICTED, true.ToString().ToLower());
			}
			else
			{
				element.AddAttribute(ELEMENT_FLAGS, this.m_flags.ToString());
			}

			return element;
		}

		public string PermissionSet
		{
			get
			{
				CustomerPermission perm = 
					new CustomerPermission(PermissionState.Unrestricted);
				NamedPermissionSet pset = 
					new NamedPermissionSet("CustomerPermissionSet", PermissionState.None);
				pset.Description = "Permission set containing the customer permission";
				pset.AddPermission(perm);
				return pset.ToXml().ToString();
			}
		}
		public override IPermission Union(IPermission other)
		{
			IPermission retVal = null;
			CustomerPermission cp = null;

			if(null == other)
			{
				retVal = this.Copy();
			}
			else
			{
				cp = other as CustomerPermission;
				
				if(null != cp)
				{
					if(true == cp.IsUnrestricted() || true == this.IsUnrestricted())
					{
						retVal = new CustomerPermission(PermissionState.Unrestricted);
					}
					else
					{
						retVal = new CustomerPermission(this.m_flags | cp.m_flags);
					}
				}
				else
				{
					throw new ArgumentException(ERROR_WRONG_ARGUMENT, "other");
				}
			}

			return retVal;
		}

		public bool IsUnrestricted()
		{
			bool retVal = false;

			if(CustomerPermissionFlag.AllAccess == this.m_flags)
			{
				retVal = true;
			}

			return retVal;
		}

		private void SetUnrestricted(bool IsUnrestricted)
		{
			if(true == IsUnrestricted)
			{
				this.m_flags = CustomerPermissionFlag.AllAccess;
			}
			else
			{
				this.m_flags = CustomerPermissionFlag.NoAccess;
			}
		}

		private void SetUnrestricted(PermissionState state)
		{
			SetUnrestricted(PermissionState.Unrestricted == state ? true : false);
		}

		public CustomerPermissionFlag Flags
		{
			get { return this.m_flags; }
			set { this.m_flags = value; }
		}
	}
}