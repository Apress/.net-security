using System;
using System.Security.Permissions;
using Apress.Chapter4.CP;

namespace CustomerPermissionTest
{
	class Test
	{
		static void Main(string[] args)
		{
			try
			{
				int testNum = 0;
				bool result = true;

				//  Test #1.
				//  Create a new unrestricted CP and
				//  make sure it's unrestricted.
				testNum++;
				CustomerPermission unrestrictedCP = 
					new CustomerPermission(PermissionState.Unrestricted);
				bool retVal = unrestrictedCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #2.
				//  Create a new restricted CP and
				//  make sure it's not restricted.
				testNum++;
				CustomerPermission noneCP = 
					new CustomerPermission(PermissionState.None);
				retVal = noneCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be false)?  " + false);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + !(retVal));
				result &= !(retVal);
				Console.WriteLine();

				//  Test #3.
				//  Create a new AllAccess CP and
				//  make sure it's unrestricted.
				testNum++;
				CustomerPermission allAccessCP = 
					new CustomerPermission(CustomerPermissionFlag.AllAccess);
				retVal = allAccessCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #4.
				//  Create a new ObjectCreation CP and
				//  make sure it's not unrestricted.
				testNum++;
				CustomerPermission objCreationCP = 
					new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				retVal = objCreationCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be false)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + !(retVal));
				result &= !(retVal);
				Console.WriteLine();

				//  Test #5.
				//  Create a new NoAccess CP and
				//  make sure it's not unrestricted.
				testNum++;
				CustomerPermission noAccessCP = 
					new CustomerPermission(CustomerPermissionFlag.NoAccess);
				retVal = noAccessCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be false)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + !(retVal));
				result &= !(retVal);
				Console.WriteLine();

				//  Test #6.
				//  Create a new unrestricted CP and
				//  union it with a NoAccess CP.
				//  Should return an unrestricted CP.
				testNum++;
				CustomerPermission unionUnrestrictedCP = 
					new CustomerPermission(PermissionState.Unrestricted);
				CustomerPermission unionResCP = 
					(CustomerPermission)unionUnrestrictedCP.Union(
						new CustomerPermission(CustomerPermissionFlag.NoAccess));
				retVal = unionResCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #7.
				//  Create a new unrestricted CP and
				//  union it with a ObjectCreation CP.
				//  Should return an unrestricted CP.
				testNum++;
				unionResCP = (CustomerPermission)unionUnrestrictedCP.Union(
					new CustomerPermission(CustomerPermissionFlag.ObjectCreation));
				retVal = unionResCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #8.
				//  Create a new unrestricted CP and
				//  union it with a AllAccess CP.
				//  Should return an unrestricted CP.
				testNum++;
				unionResCP = (CustomerPermission)unionUnrestrictedCP.Union(
					new CustomerPermission(CustomerPermissionFlag.AllAccess));
				retVal = unionResCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();
				
				//  Test #9.
				//  Create a new ObjectCreation CP and
				//  union it with a AllAccess CP.
				//  Should return an unrestricted CP.
				testNum++;
				CustomerPermission unionObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				unionResCP = (CustomerPermission)unionObjCreationCP.Union(
					new CustomerPermission(CustomerPermissionFlag.AllAccess));
				retVal = unionResCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #10.
				//  Create a new ObjectCreation CP and
				//  union it with a ObjectCreation CP.
				//  Should return an restricted CP.
				testNum++;
				unionObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				unionResCP = (CustomerPermission)unionObjCreationCP.Union(
					new CustomerPermission(CustomerPermissionFlag.ObjectCreation));
				retVal = unionResCP.IsUnrestricted();
				Console.WriteLine("Is unrestricted (should be false)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + !(retVal));
				result &= !(retVal);
				Console.WriteLine();
				
				//  Test #11.
				//  Create a new ObjectCreation CP and
				//  intersect it with an unrestricted.
				//  Should return an ObjectCreation CP.
				testNum++;
				CustomerPermission interObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				CustomerPermission interResCP = (CustomerPermission)interObjCreationCP.Intersect(
					new CustomerPermission(PermissionState.Unrestricted));
				retVal = CustomerPermissionFlag.ObjectCreation == interResCP.Flags;
				Console.WriteLine("Is Flags = ObjectCreation?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #12.
				//  Create a new ObjectCreation CP and
				//  intersect it with an NoAccess.
				//  Should return an NoAccess CP.
				testNum++;
				interObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				interResCP = (CustomerPermission)interObjCreationCP.Intersect(
					new CustomerPermission(CustomerPermissionFlag.NoAccess));
				retVal = CustomerPermissionFlag.NoAccess == interResCP.Flags;
				Console.WriteLine("Is Flags = NoAccess?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #13.
				//  Create a new ObjectCreation CP and
				//  call IsSubsetOf with a AllAccess CP.
				//  Should return true.
				testNum++;
				interObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				retVal = interObjCreationCP.IsSubsetOf(
					new CustomerPermission(CustomerPermissionFlag.AllAccess));
				Console.WriteLine("Is subset of (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #14.
				//  Create a new ObjectCreation CP and
				//  call IsSubsetOf with a NoAccess CP.
				//  Should return false.
				testNum++;
				interObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				retVal = interObjCreationCP.IsSubsetOf(
					new CustomerPermission(CustomerPermissionFlag.NoAccess));
				Console.WriteLine("Is subset of (should be false)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + !(retVal));
				result &= !(retVal);
				Console.WriteLine();

				//  Test #15.
				//  Create a new ObjectCreation CP and
				//  call IsSubsetOf with a ObjectCreation CP.
				//  Should return true.
				testNum++;
				interObjCreationCP = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				retVal = interObjCreationCP.IsSubsetOf(
					new CustomerPermission(CustomerPermissionFlag.ObjectCreation));
				Console.WriteLine("Is subset of (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #16
				//  Check XML round-tripping.
				CustomerPermission cpToXML = new CustomerPermission(CustomerPermissionFlag.ObjectCreation);
				String cpToXMLValue = cpToXML.ToXml().ToString();
				CustomerPermission cpFromXML = new CustomerPermission(CustomerPermissionFlag.NoAccess);
				cpFromXML.FromXml(cpToXML.ToXml());
				String cpFromXMLValue = cpFromXML.ToXml().ToString();
				retVal = cpToXMLValue.Equals(cpFromXMLValue);
				Console.WriteLine("Is XML the same (should be true)?  " + retVal);
				Console.WriteLine("Test #" + testNum + ":  Passed?  " + retVal);
				result &= retVal;
				Console.WriteLine();

				//  Test #17.
				//  Generate an XML representation.
				cpToXML = new CustomerPermission(CustomerPermissionFlag.AllAccess);
				cpToXMLValue = cpToXML.ToXml().ToString();
				Console.WriteLine(cpToXMLValue);

				Console.WriteLine();
				Console.WriteLine("Did all of the tests pass?  " + result);
			}
			catch(Exception e)
			{

			}
			finally
			{
				Console.WriteLine("Press return to continue...");
				Console.ReadLine();
			}
		}
	}
}
