using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security;
using System.Security.Permissions;
using System.Data;
using Apress.Chapter4.CP;

[assembly: CustomerPermissionAttribute(SecurityAction.RequestRefuse, Flags=CustomerPermissionFlag.NoAccess)]

namespace CustomerPermissionTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnTest;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnTest = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnTest
			// 
			this.btnTest.Location = new System.Drawing.Point(8, 8);
			this.btnTest.Name = "btnTest";
			this.btnTest.TabIndex = 0;
			this.btnTest.Text = "Test";
			this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnTest});
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Customer Permission Test";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		[method: CustomerPermissionAttribute(SecurityAction.Demand, 
					 Flags=CustomerPermissionFlag.AllAccess)]
		private void btnTest_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("About to make the Customer object...");
			Customer c = new Customer("Jason", "Bock", 123);
			MessageBox.Show("First name is " + c.FirstName);
			c.FirstName = "Pete";
			MessageBox.Show("First name is " + c.FirstName);
			MessageBox.Show("ID is " + c.ID);

			CustomerPermission cp = new CustomerPermission(CustomerPermissionFlag.AllAccess);
			cp.Deny();
			
			c.ID = 456;
			MessageBox.Show("ID is " + c.ID);
		}
	}
}
