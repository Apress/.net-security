using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Reflection;
using System.Security;
using System.Security.Policy;
using System.Security.Permissions;
using System.Runtime.Remoting.Activation;
using Magenic.EmployeeLibrary;
using ErrorDialog;

namespace Magenic
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class EmployeeClientTest : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblFirstName;
		private System.Windows.Forms.TextBox txtFirstNameValue;
		private System.Windows.Forms.TextBox txtLastNameValue;
		private System.Windows.Forms.Label lblLastName;
		private System.Windows.Forms.TextBox txtImageSourceValue;
		private System.Windows.Forms.Label lblImageSource;
		private System.Windows.Forms.Button btnCreateEmployee;
		private System.Windows.Forms.TextBox txtImageDestinationValue;
		private System.Windows.Forms.Label lblImageDestination;
		private System.Windows.Forms.PictureBox pctImage;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public EmployeeClientTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblFirstName = new System.Windows.Forms.Label();
			this.txtFirstNameValue = new System.Windows.Forms.TextBox();
			this.txtLastNameValue = new System.Windows.Forms.TextBox();
			this.lblLastName = new System.Windows.Forms.Label();
			this.txtImageSourceValue = new System.Windows.Forms.TextBox();
			this.lblImageSource = new System.Windows.Forms.Label();
			this.btnCreateEmployee = new System.Windows.Forms.Button();
			this.txtImageDestinationValue = new System.Windows.Forms.TextBox();
			this.lblImageDestination = new System.Windows.Forms.Label();
			this.pctImage = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// lblFirstName
			// 
			this.lblFirstName.Location = new System.Drawing.Point(8, 8);
			this.lblFirstName.Name = "lblFirstName";
			this.lblFirstName.Size = new System.Drawing.Size(104, 16);
			this.lblFirstName.TabIndex = 0;
			this.lblFirstName.Text = "First Name:";
			this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtFirstNameValue
			// 
			this.txtFirstNameValue.Location = new System.Drawing.Point(112, 8);
			this.txtFirstNameValue.MaxLength = 50;
			this.txtFirstNameValue.Name = "txtFirstNameValue";
			this.txtFirstNameValue.Size = new System.Drawing.Size(168, 20);
			this.txtFirstNameValue.TabIndex = 1;
			this.txtFirstNameValue.Text = "";
			// 
			// txtLastNameValue
			// 
			this.txtLastNameValue.Location = new System.Drawing.Point(112, 32);
			this.txtLastNameValue.MaxLength = 50;
			this.txtLastNameValue.Name = "txtLastNameValue";
			this.txtLastNameValue.Size = new System.Drawing.Size(168, 20);
			this.txtLastNameValue.TabIndex = 3;
			this.txtLastNameValue.Text = "";
			// 
			// lblLastName
			// 
			this.lblLastName.Location = new System.Drawing.Point(8, 32);
			this.lblLastName.Name = "lblLastName";
			this.lblLastName.Size = new System.Drawing.Size(104, 16);
			this.lblLastName.TabIndex = 2;
			this.lblLastName.Text = "Last Name:";
			this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtImageSourceValue
			// 
			this.txtImageSourceValue.Location = new System.Drawing.Point(112, 56);
			this.txtImageSourceValue.MaxLength = 0;
			this.txtImageSourceValue.Name = "txtImageSourceValue";
			this.txtImageSourceValue.Size = new System.Drawing.Size(168, 20);
			this.txtImageSourceValue.TabIndex = 5;
			this.txtImageSourceValue.Text = "C:\\assembly\\lizandi.jpg";
			// 
			// lblImageSource
			// 
			this.lblImageSource.Location = new System.Drawing.Point(8, 56);
			this.lblImageSource.Name = "lblImageSource";
			this.lblImageSource.Size = new System.Drawing.Size(104, 16);
			this.lblImageSource.TabIndex = 4;
			this.lblImageSource.Text = "Image Source:";
			this.lblImageSource.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnCreateEmployee
			// 
			this.btnCreateEmployee.Location = new System.Drawing.Point(8, 112);
			this.btnCreateEmployee.Name = "btnCreateEmployee";
			this.btnCreateEmployee.Size = new System.Drawing.Size(104, 24);
			this.btnCreateEmployee.TabIndex = 8;
			this.btnCreateEmployee.Text = "Create Employee";
			this.btnCreateEmployee.Click += new System.EventHandler(this.btnCreateEmployee_Click);
			// 
			// txtImageDestinationValue
			// 
			this.txtImageDestinationValue.Location = new System.Drawing.Point(112, 80);
			this.txtImageDestinationValue.MaxLength = 0;
			this.txtImageDestinationValue.Name = "txtImageDestinationValue";
			this.txtImageDestinationValue.Size = new System.Drawing.Size(168, 20);
			this.txtImageDestinationValue.TabIndex = 7;
			this.txtImageDestinationValue.Text = "afile.jpg";
			// 
			// lblImageDestination
			// 
			this.lblImageDestination.Location = new System.Drawing.Point(8, 80);
			this.lblImageDestination.Name = "lblImageDestination";
			this.lblImageDestination.Size = new System.Drawing.Size(104, 16);
			this.lblImageDestination.TabIndex = 6;
			this.lblImageDestination.Text = "Image Destination:";
			this.lblImageDestination.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pctImage
			// 
			this.pctImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pctImage.Location = new System.Drawing.Point(8, 144);
			this.pctImage.Name = "pctImage";
			this.pctImage.Size = new System.Drawing.Size(272, 192);
			this.pctImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctImage.TabIndex = 9;
			this.pctImage.TabStop = false;
			// 
			// EmployeeClientTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 349);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pctImage,
																		  this.txtImageDestinationValue,
																		  this.lblImageDestination,
																		  this.btnCreateEmployee,
																		  this.txtImageSourceValue,
																		  this.lblImageSource,
																		  this.txtLastNameValue,
																		  this.lblLastName,
																		  this.txtFirstNameValue,
																		  this.lblFirstName});
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "EmployeeClientTest";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Employee Test Client";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new EmployeeClientTest());
		}

		private void btnCreateEmployee_Click(object sender, System.EventArgs e)
		{
			try
			{
				FileStream fs = File.OpenRead(this.txtImageSourceValue.Text);
				byte[] imageData = new Byte[fs.Length];
				fs.Read(imageData, 0, (int)fs.Length);
				fs.Close();

				IEmployee emp = new Employee(
					this.txtFirstNameValue.Text,
					this.txtLastNameValue.Text,
					Guid.NewGuid(), imageData);

				emp.SaveImage(this.txtImageDestinationValue.Text);
				this.pctImage.SizeMode = PictureBoxSizeMode.StretchImage;
				Bitmap empImage = new Bitmap(Employee.IMAGE_DIR + 
					this.txtImageDestinationValue.Text);
				this.pctImage.Image = (Image)empImage;
			}
			catch(Exception ex)
			{
				ErrorForm ef = new ErrorForm(ex);
				ef.ShowDialog(this);
			}
		}
	}
}
