using System;
using System.IO;
using System.Security.Permissions;

namespace Magenic.EmployeeLibrary
{
	public interface IEmployee
	{
		string FirstName
		{
			get;
			set;
		}

		string LastName
		{
			get;
			set;
		}

		Guid ID
		{
			get;
			set;
		}

		byte[] Image
		{
			get;
			set;
		}

		void SaveImage(string FileName);
	}

	public class Employee : IEmployee
	{
		public const string IMAGE_DIR = 
			@"C:\assembly\EmployeeImages\";
		private string m_FirstName, m_LastName;
		private Guid m_ID;
		private byte[] m_Image;

		private Employee() : base() {}

		public Employee(string FirstName, string LastName, 
			Guid ID, byte[] Image)
		{
			this.m_FirstName = FirstName;
			this.m_LastName = LastName;
			this.m_ID = ID;
			this.m_Image = Image;
		}

		public string FirstName
		{
			get
			{
				return this.m_FirstName;
			}
			set
			{
				this.m_FirstName = value;
			}
		}

		public string LastName
		{
			get
			{
				return this.m_LastName;
			}
			set
			{
				this.m_LastName = value;
			}
		}

		public Guid ID
		{
			get
			{
				return this.m_ID;
			}
			set
			{
				this.m_ID = value;
			}
		}

		public byte[] Image
		{
			get
			{
				return this.m_Image;
			}
			set
			{
				this.m_Image = value;
			}
		}

		[method: FileIOPermission(SecurityAction.Demand, Write = IMAGE_DIR)]
		public void SaveImage(string FileName)
		{
			FileName = IMAGE_DIR + FileName;

			if(true == File.Exists(FileName))
			{
				File.Delete(FileName);
			}

			FileStream fs = File.Create(FileName);
			fs.Write(this.m_Image, 0, (int)this.m_Image.Length);
			fs.Close();
		}
	}
}
