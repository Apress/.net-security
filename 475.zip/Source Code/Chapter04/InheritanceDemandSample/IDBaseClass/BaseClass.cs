using System;
using System.Security.Permissions;

namespace IDBaseClass
{
    public class BaseClass
    {
        [method: ReflectionPermission(
                     SecurityAction.InheritanceDemand, 
                     Flags=ReflectionPermissionFlag.ReflectionEmit)]
        public virtual void SomeMethod() 
        {
            Console.WriteLine("BaseClass.SomeMethod()...");            
        }
    }
}

