using System;
using System.Security.Permissions;
using IDBaseClass;

[assembly: ReflectionPermission(SecurityAction.RequestRefuse, Flags=ReflectionPermissionFlag.ReflectionEmit)]
namespace IDDerivedClass
{
    public class DerivedClass : BaseClass
    {
        public override void SomeMethod() 
        {
            Console.WriteLine("DerivedClass.SomeMethod()...");                    
        } 
    }
}

