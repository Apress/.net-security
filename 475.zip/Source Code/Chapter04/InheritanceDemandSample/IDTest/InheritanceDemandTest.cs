using System;
using IDBaseClass;
using IDDerivedClass;

namespace IDTest
{
	class InheritanceDemandTest
	{
		static void Main(string[] args)
		{
            DerivedClass dc = new DerivedClass();
            dc.SomeMethod();
		}
	}
}
