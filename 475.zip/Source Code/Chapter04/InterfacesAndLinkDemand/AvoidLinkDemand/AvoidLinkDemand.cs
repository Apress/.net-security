using System;
using System.Security.Permissions;

namespace AvoidLinkDemand
{
	public interface IPhone
	{
		bool Dial(string PhoneNumber);
	}

	public class Phone : IPhone
	{
		public Phone()
		{
		}

		[StrongNameIdentityPermission(SecurityAction.LinkDemand, 
			 PublicKey="0024000004800000940000000602000000240000525341310004000001000100EB041A667B421A55345B83173FE2F4B4F66D4FCFD5D9AD54BC5C77DA743EB3CA6F28286092ADB9F24B534CF152C5859F9D1EF7B3B5ED77C4D2F656F789C63F06055EADC9D0D6294566F16A0F25622FAF12F2F98D917BCE0891C1F129256FC374480BD550DBD3C2FA337BBEC562A99D913F42A9C3BD67CA141F86AEE631C6049A")]
		public bool Dial(string PhoneNumber)
		{
			bool retVal = false;

			if(PhoneNumber.Equals("555-1212"))
			{
				retVal = true;
			}

			return retVal;
		}
	}
}
