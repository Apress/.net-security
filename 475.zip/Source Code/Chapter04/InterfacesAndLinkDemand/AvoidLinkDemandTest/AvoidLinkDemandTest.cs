using System;
using AvoidLinkDemand;

namespace AvoidLinkDemandTest
{
	class ALDT
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				IPhone p = new Phone();
				Console.WriteLine("Dialing 555-9999...");
				Console.WriteLine(p.Dial("555-9999"));
				Console.WriteLine("Dialing 555-1212...");
				Console.WriteLine(p.Dial("555-1212"));
			}
			catch(Exception e)
			{
				Console.WriteLine(e);
			}
			finally
			{
				Console.WriteLine("Press any key to continue...");
				Console.ReadLine();
			}
		}
	}
}
