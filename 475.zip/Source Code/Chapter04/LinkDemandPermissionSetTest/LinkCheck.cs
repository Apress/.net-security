using System;
using System.IO;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Security.Policy;

namespace LinkDemandTest
{
	class LinkCheck
	{
		[STAThread]
		[FileIOPermission(SecurityAction.Demand, Read=@"C:\Program Files")]
		[FileIOPermission(SecurityAction.Demand, Write=@"C:\ADirectory")]
		static void Main(string[] args)
		{
			FileStream fs1 = new FileStream(@"CallerA.snk", FileMode.Open);
			StrongNameKeyPair snkp1 = new StrongNameKeyPair(fs1);
			StrongNamePublicKeyBlob p1Blob = new StrongNamePublicKeyBlob(snkp1.PublicKey);
			StrongNameIdentityPermission s1 = 
				new StrongNameIdentityPermission(p1Blob, "CallerA", new Version());

			FileStream fs2 = new FileStream(@"CallerB.snk", FileMode.Open);
			StrongNameKeyPair snkp2 = new StrongNameKeyPair(fs2);
			StrongNamePublicKeyBlob p2Blob = new StrongNamePublicKeyBlob(snkp2.PublicKey);
			StrongNameIdentityPermission s2 = 
				new StrongNameIdentityPermission(p2Blob, "CallerB", new Version());

			PermissionSet psSNAdd = new PermissionSet(PermissionState.None);
			psSNAdd.AddPermission(s1);
			Console.WriteLine("With just s1:  " + psSNAdd.ToXml().ToString());
			Console.WriteLine("Count = " + psSNAdd.Count);
			psSNAdd.AddPermission(s2);
			Console.WriteLine("With both:  " + psSNAdd.ToXml().ToString());
			Console.WriteLine("Count = " + psSNAdd.Count);

			FileIOPermission f1 = new FileIOPermission(FileIOPermissionAccess.Read, @"C:\Program Files");
			FileIOPermission f2 = new FileIOPermission(FileIOPermissionAccess.Write, @"C:\ADirectory");

			PermissionSet psFileAdd = new PermissionSet(PermissionState.None);
			psFileAdd.AddPermission(f1);
			Console.WriteLine("With just f1:  " + psFileAdd.ToXml().ToString());
			Console.WriteLine("Count = " + psFileAdd.Count);
			psFileAdd.AddPermission(f2);
			Console.WriteLine("With both:  " + psFileAdd.ToXml().ToString());
			Console.WriteLine("Count = " + psFileAdd.Count);
		}
	}
}
