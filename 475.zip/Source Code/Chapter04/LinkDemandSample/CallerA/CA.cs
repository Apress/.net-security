using System;
using LinkDemandTest;

namespace CallerA
{
	class CA
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				LDT ldt = new LDT();
				Console.WriteLine("Calling MethodOne().");
				ldt.MethodOne();
				Console.WriteLine("MethodOne() complete.");
				Console.WriteLine("Calling MethodTwo().");
				ldt.MethodTwo();
				Console.WriteLine("MethodTwo() complete.");
			}
			catch(Exception e)
			{
				Console.WriteLine(e);
			}
			finally
			{
				Console.WriteLine("Press any key to continue...");
				Console.ReadLine();
			}
		}
	}
}
