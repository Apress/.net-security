using System;
using LinkDemandTest;

namespace CallerC
{
	class CC
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				LDT ldt = new LDT();
				Console.WriteLine("Calling MethodOne().");
				ldt.MethodOne();
				Console.WriteLine("MethodOne() complete.");
			}
			catch(Exception e)
			{
				Console.WriteLine(e);
			}
			finally
			{
				Console.WriteLine("Press any key to continue...");
				Console.ReadLine();
			}
		}
	}
}
