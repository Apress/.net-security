using System;
using System.Collections;
using System.Reflection;
using System.Security;
using System.Security.Policy;
using System.Security.Permissions;

namespace PermissionSetSample
{
	class PermissionSetSampleTest
	{
        private static bool isLevelFinal = false;
        private static CodeGroup exclusiveCodeGroup = null;

		static void Main(string[] args)
		{
            PermissionSet ps = SecurityManager.ResolvePolicy(
                Assembly.GetExecutingAssembly().Evidence);
            Console.WriteLine("Permission set count is " + ps.Count);
            IEnumerator perms = ps.GetEnumerator();
            while(perms.MoveNext())
            {
                IPermission p = perms.Current as IPermission;
                Console.WriteLine(p.ToString());
            }

            GetPermissions();
        }

        private static void GetPermissions()
        {
            Evidence e = Assembly.GetExecutingAssembly().Evidence;				
            PermissionSet allPS = new PermissionSet(null);
            IEnumerator policies = SecurityManager.PolicyHierarchy();
            while(policies.MoveNext())
            {
                PolicyLevel pl = policies.Current as PolicyLevel;
                CodeGroup cg = pl.ResolveMatchingCodeGroups(e);
                isLevelFinal = false;
                exclusiveCodeGroup = null;
                WalkCodeGroup(cg);

                IEnumerator perms = null;
                if(exclusiveCodeGroup == null)
                {
                    PolicyStatement ps = pl.Resolve(e);
                    perms = ps.PermissionSet.GetEnumerator();
                }
                else
                {
                    perms = exclusiveCodeGroup.PolicyStatement.PermissionSet.GetEnumerator();
                }
    
                while(perms.MoveNext())
                {
                    IPermission exp = perms.Current as IPermission;
                    allPS.SetPermission(exp);
                }
    
                if(isLevelFinal)
                {
                    break;
                }
            }

			Console.WriteLine("-----------------------");
			Console.WriteLine("Printing permissions...");
			Console.WriteLine("-----------------------");
			Console.WriteLine();
			IEnumerator allPerms = allPS.GetEnumerator();
            while(allPerms.MoveNext())
            {
                IPermission ps = allPerms.Current as IPermission;
				Console.WriteLine(ps.ToXml());
            }    
        }

        private static void WalkCodeGroup(CodeGroup cg)
        {
            PolicyStatementAttribute psa = cg.PolicyStatement.Attributes;
			
            int res = (int)(psa & PolicyStatementAttribute.LevelFinal);
            if(0 < res)
            {
                isLevelFinal = true;
            }

            res = (int)(psa & PolicyStatementAttribute.Exclusive);
            if(0 < res && exclusiveCodeGroup == null)
            {
                exclusiveCodeGroup = cg;
            }

            IList cgChildren = cg.Children;
            if(null != cgChildren && 0 < cgChildren.Count)
            {
                IEnumerator cgChilds = cgChildren.GetEnumerator();
                while(cgChilds.MoveNext())
                {
                    CodeGroup cgChild = cgChilds.Current as CodeGroup;
                    WalkCodeGroup(cgChild);
                }
            }
        }
	}
}
