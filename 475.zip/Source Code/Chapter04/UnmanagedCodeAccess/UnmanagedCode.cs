//  Compile at the command-line:
//  csc /target:library UnmanagedCode.cs

using System.Security;
using System.Runtime.InteropServices;

public class UnmanagedCode
{
    [SuppressUnmanagedCodeSecurityAttribute()]
    [DllImport("Kernel32.DLL")]
    private static extern int GetTickCount();

    public int GetUnmanagedTickCount()
    {
        return GetTickCount();
    }
}