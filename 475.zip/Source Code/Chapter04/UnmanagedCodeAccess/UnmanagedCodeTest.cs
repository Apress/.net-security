//  Compile at the command-line:
//  csc /r:UnmanagedCode.dll /target:exe UnmanagedCodeTest.cs

using System;
using System.Security.Permissions;

[assembly:SecurityPermission(SecurityAction.RequestRefuse, UnmanagedCode=true)]
public class UnmanagedCodeTest
{
    static void Main(string[] args)
    {
         UnmanagedCode uc = new UnmanagedCode();
         Console.WriteLine(uc.GetUnmanagedTickCount());
    }
}