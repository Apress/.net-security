using System;
using System.Threading;
using System.Security.Permissions;
using System.Security.Principal;

namespace IdentityTest
{
	class IT
	{
		[STAThread]
		static void Main(string[] args)
		{
			IIdentity genericNameOnly = new GenericIdentity("jbock");
			IIdentity genericNoNameOnly = new GenericIdentity("");
			IIdentity genericNameAndTypeK = new GenericIdentity("jbock", "Kerebos");
			IIdentity genericNameAndTypeNT = new GenericIdentity("jbock", "NTLM");
			
			Console.WriteLine("Name only - is it authenticated?  " + genericNameOnly.IsAuthenticated.ToString());
			Console.WriteLine("No name only - is it authenticated?  " + genericNoNameOnly.IsAuthenticated.ToString());
			Console.WriteLine("Name + Kerebos - is it authenticated?  " + genericNameAndTypeK.IsAuthenticated.ToString());
			Console.WriteLine("Name + NT - is it authenticated?  " + genericNameAndTypeNT.IsAuthenticated.ToString());

			IIdentity currentWindowsUser = WindowsIdentity.GetCurrent();
			Console.WriteLine("Windows user - is it authenticated?  " + currentWindowsUser.IsAuthenticated.ToString());
			Console.WriteLine("Windows user - name?  " + currentWindowsUser.Name);
			Console.WriteLine("Windows user - authentication type?  " + currentWindowsUser.AuthenticationType);

			IIdentity anonWindowsUser = WindowsIdentity.GetAnonymous();
			Console.WriteLine("anon user - is it authenticated?  " + anonWindowsUser.IsAuthenticated.ToString());
			Console.WriteLine("anon user - name?  " + anonWindowsUser.Name);
			Console.WriteLine("anon user - authentication type?  " + anonWindowsUser.AuthenticationType);

			string[] roles = {"administrators", "developers"};
			GenericPrincipal genericPrincipal = 
				new GenericPrincipal(genericNameOnly, roles);
			
			Console.WriteLine("Is the principal in the developer's role?  " + 
				genericPrincipal.IsInRole("developers"));
			Console.WriteLine("Is the principal in the accountant's role  " + 
				genericPrincipal.IsInRole("accountants"));

			WindowsPrincipal winPrincipal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
			Console.WriteLine("Is the principal in the administrator's role?  " +
				winPrincipal.IsInRole(@"weinstefaner\Administrators"));
			Console.WriteLine("Is the principal in the administrator's role?  " +
				winPrincipal.IsInRole(@"BUILTIN\Administrators"));
			Console.WriteLine("Is the principal in the administrator's role?  " +
				winPrincipal.IsInRole(WindowsBuiltInRole.Administrator));
			Console.WriteLine("Is the principal in the Power User's role?  " +
				winPrincipal.IsInRole(WindowsBuiltInRole.PowerUser));
			Console.WriteLine("Is the principal in the administrator's role?  " +
				winPrincipal.IsInRole(0x00000220));
			Console.WriteLine("Is the principal in the Power User's role?  " +
				winPrincipal.IsInRole(0x00000223));

			IPrincipal currentPrincipal = Thread.CurrentPrincipal;
			IIdentity currentIdentity = currentPrincipal.Identity;
			Console.WriteLine("Current user - is it authenticated?  " + 
				currentIdentity.IsAuthenticated.ToString());
			Console.WriteLine("Current user - name?  " + 
				currentIdentity.Name);
			Console.WriteLine("Current user - authentication type?  " + 
				currentIdentity.AuthenticationType);

			string[] managerRoles = {"Manager", "Cook"};
			string[] cookRoles = {"Cook"};
			IIdentity managerIdentity = new GenericIdentity("Jane");
			IPrincipal managerPrincipal = new GenericPrincipal(managerIdentity, managerRoles);
			IIdentity cookIdentity = new GenericIdentity("Joe");
			IPrincipal cookPrincipal = new GenericPrincipal(cookIdentity, cookRoles);

			try
			{
				PrincipalPermission prinPerm = new PrincipalPermission(null, "Manager");
				prinPerm.Demand();
				Console.WriteLine("The demand worked.");				
			}
			catch(Exception demandEx)
			{
				Console.WriteLine("Could not demand the permission:  " + 
					demandEx.Message);
			}

			try
			{
				RunCookCode();
			}
			catch(Exception CookEx)
			{
				Console.WriteLine("Could not run the Cook's code:  " + 
					CookEx.Message);
			}

			try
			{
				RunManagerCode();
			}
			catch(Exception managerEx)
			{
				Console.WriteLine("Could not run the managers's code:  " + 
					managerEx.Message);
			}

			try
			{
				RunCookOrManagerJoesCode();
			}
			catch(Exception managerEx)
			{
				Console.WriteLine("Could not run Cook or manager Joe's code:  " + 
					managerEx.Message);
			}		

			try
			{
				RunAuthenticatedManagerJoesCode();
			}
			catch(Exception managerEx)
			{
				Console.WriteLine("Could not run authenticated manager Joe's code:  " + 
					managerEx.Message);
			}	
	
			IIdentity fakeWindowsIdentity = new GenericIdentity(@"WEINSTEFANER\Administrator");
			IPrincipal fakeWindowsPrincipal = new GenericPrincipal(fakeWindowsIdentity, null);
			Thread.CurrentPrincipal = fakeWindowsPrincipal;
			
			try
			{
				RunWindowsAdminCode();
			}
			catch(Exception windowsAdminEx)
			{
				Console.WriteLine("Could not run Windows admin code:  " + 
					windowsAdminEx.Message + 
					windowsAdminEx.ToString());
			}		
		}

		[PrincipalPermission(SecurityAction.Demand, Role="Manager")]
		private static void RunManagerCode()
		{
			Console.WriteLine("Manager work goes here...");
		}

		[PrincipalPermission(SecurityAction.Demand, Name=@"WEINSTEFANER\Administrator")]
		private static void RunWindowsAdminCode()
		{
			Console.WriteLine("Windows admin work goes here...");
		}

		[PrincipalPermission(SecurityAction.Demand, Authenticated=true, Role="Manager", Name="Joe")]
		private static void RunAuthenticatedManagerJoesCode()
		{
			Console.WriteLine("Authenticated manager Joe's work goes here...");
		}

		[PrincipalPermission(SecurityAction.Demand, Role="Cook")]
		private static void RunCookCode()
		{
			Console.WriteLine("Cook work goes here...");
		}	

		[PrincipalPermission(SecurityAction.Demand, Role="Cook")]
		[PrincipalPermission(SecurityAction.Demand, Role="Manager", Name="Joe")]
		private static void RunCookOrManagerJoesCode()
		{
			Console.WriteLine("Cook or manager Joe's work goes here...");
		}	
	}
}
