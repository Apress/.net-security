using System;
using System.Reflection;
using System.Runtime.Remoting;
using System.Threading;
using System.Security.Permissions;
using System.Security.Policy;
using System.Security.Principal;

namespace PPLauncher
{
	class LauncherClass
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				AppDomain newAD = AppDomain.CreateDomain("ApressDomain");
				//  The principal will always be based on the Windows identity.
				String[] adRole = {"BigBucksClub"};
				IIdentity adRoleIdentity = new GenericIdentity(@"WEINSTEFANER\Administrator");
				Console.WriteLine("Creating the AD role principal.");
				IPrincipal adRolePrincipal = new GenericPrincipal(adRoleIdentity, adRole);
				
				newAD.SetThreadPrincipal(new WindowsPrincipal(WindowsIdentity.GetCurrent()));
				//  Now restrict this change for all download callers.
				SecurityPermission sp = new SecurityPermission(SecurityPermissionFlag.ControlPrincipal);
				sp.Deny();
				
				int ret = newAD.ExecuteAssembly(@"D:\assembly\PPTester.exe");
			}
			catch(Exception ex)
			{
				Console.WriteLine(
					ex.ToString());
			}	
		}
	}
}
