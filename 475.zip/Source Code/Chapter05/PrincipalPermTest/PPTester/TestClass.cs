using System;
using System.Reflection;
using System.Runtime.Remoting;
using System.Threading;
using System.Security.Permissions;
using System.Security.Policy;
using System.Security.Principal;

namespace PPTester
{
	class TestClass
	{
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine("Main entered.");
			Console.WriteLine("Identity name:  " + Thread.CurrentPrincipal.Identity.Name);
			Privleged p = new Privleged();
			IIdentity fakeWindowsIdentity = new GenericIdentity(@"WEINSTEFANER\Administrator");

			Console.WriteLine("Creating the fake Windows principal.");
			IPrincipal fakeWindowsPrincipal = new GenericPrincipal(fakeWindowsIdentity, null);
			Console.WriteLine("Setting the thread's principal.");
			Thread.CurrentPrincipal = fakeWindowsPrincipal;
			p.SpecificWindowsUserOnly();
			Console.WriteLine("SpecificWindowsUserOnly() called.");
			String[] fakeRole = {"BigBucksClub"};
			IIdentity fakeRoleIdentity = new GenericIdentity(@"BigBucksWannabe");
			
			Console.WriteLine("Creating the fake role principal.");
			IPrincipal fakeRolePrincipal = new GenericPrincipal(fakeRoleIdentity, fakeRole);
			Console.WriteLine("Setting the thread's principal.");
			Thread.CurrentPrincipal = fakeRolePrincipal;
			p.SpecificRoleMembershipOnly();
			Console.WriteLine("SpecificRoleMembershipOnly() called.");
		}
	}

	public class Privleged
	{
		public Privleged()
		{
		}
	
		[PrincipalPermission(SecurityAction.Demand, Role="BigBucksClub")]
		public void SpecificRoleMembershipOnly()
		{
			Console.WriteLine("A privileged role member has arrived...");
		}	

		[PrincipalPermission(SecurityAction.Demand, Name=@"WEINSTEFANER\Administrator")]
		public void SpecificWindowsUserOnly()
		{
			Console.WriteLine("A specific Windows user has arrived...");
		}	
	}
}
