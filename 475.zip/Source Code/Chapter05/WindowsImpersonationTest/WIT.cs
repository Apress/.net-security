using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Threading;
using System.Text;
using System.Security.Permissions;
using System.Security.Policy;
using System.Security.Principal;

namespace WindowsImpersonationTest
{
	class WIT
	{
		private static String t_Domain = null;
		private static String t_Password = null;
		private static String t_UserName = null;
		private const int LOGON32_LOGON_NETWORK	= 3;
		private const int LOGON32_PROVIDER_DEFAULT = 0;
		private const int FORMAT_MESSAGE_FROM_SYSTEM = 0x00001000;
		private const int FORMAT_MESSAGE_ALLOCATE_BUFFER = 0x00000100;

		[DllImport("advapi32.dll")]
		static extern int LogonUser(String UserName, String Domain, String Password, 
			int LogonType, int LogonProvider, ref IntPtr WindowToken);

		
		[DllImport("kernel32.dll", CharSet=CharSet.Auto)]
		static extern int FormatMessage(int Flags, ref IntPtr MessageSource, int MessageID, 
			int LanguageID, ref IntPtr Buffer, int BufferSize, int Arguments);

		[DllImport("kernel32.dll")]
		static extern bool CloseHandle(IntPtr Handle);

		[DllImport("kernel32.dll")]
		static extern int GetLastError();

		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				Console.WriteLine("Main entered...");
				GetLogonInformation();

				Console.WriteLine("Attempting logon...");
				IntPtr windowsToken  = IntPtr.Zero;
				int logonRetVal = LogonUser(t_UserName, t_Domain, t_Password, 
					LOGON32_LOGON_NETWORK, LOGON32_PROVIDER_DEFAULT, 
					ref windowsToken);
				
				if(0 != logonRetVal)
				{
					Console.WriteLine("Logon successful.");
					WindowsIdentity newWI = new WindowsIdentity(windowsToken);
					Console.WriteLine("Logon name:  " + newWI.Name);
					IIdentity curIdent = Thread.CurrentPrincipal.Identity;
					Console.WriteLine("Current identity from the thread " + 
						"before impersonation:  " 
						+ curIdent.Name);
					WindowsImpersonationContext wic = newWI.Impersonate();
					WindowsIdentity currentWI = WindowsIdentity.GetCurrent();
					Console.WriteLine("Current Windows name after impersonation:  " + 
						currentWI.Name);
					curIdent = Thread.CurrentPrincipal.Identity;
					Console.WriteLine("Current identity from the thread " + 
						"after impersonation:  " 
						+ curIdent.Name);
					wic.Undo();
					currentWI = WindowsIdentity.GetCurrent();
					Console.WriteLine("Current Windows name after Undo():  " + 
						currentWI.Name);
					CloseHandle(windowsToken);
				}
				else
				{
					throw new Exception("Error occurred with LogonUser().  " +
						"Error number:  " + GetLastError() + ", " + 
						"Error message:  " + CreateLogonUserError(GetLastError()));
				}

			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}
			finally
			{
				Console.WriteLine("Press any key to continue...");
				Console.ReadLine();
			}
		}

		private static void GetLogonInformation()
		{
			Console.WriteLine("Please enter the user name.");
			t_UserName = Console.ReadLine();
			Console.WriteLine("Please enter the password.");
			t_Password = Console.ReadLine();
			Console.WriteLine("Please enter the domain.");
			t_Domain = Console.ReadLine();
		}

		private static String CreateLogonUserError(int ErrorCode)
		{
			IntPtr bufferPtr = IntPtr.Zero;
			IntPtr messageSource = IntPtr.Zero;

			int retVal = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 
				ref messageSource, 
				ErrorCode, 0, ref bufferPtr, 1, 0);
			
			string strRetval = Marshal.PtrToStringAuto(bufferPtr, retVal);

			return strRetval;
		}
	}
}
