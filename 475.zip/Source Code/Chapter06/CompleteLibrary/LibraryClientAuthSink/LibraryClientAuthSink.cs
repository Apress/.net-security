using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting.Messaging;
using System.Net;
using System.Collections;
using System.IO;

namespace LibraryClientAuthSink
{

	public class ClientAuthenticationProvider : IClientChannelSinkProvider
	{
		//private data
		private IClientChannelSinkProvider _nextProvider = null;
		private CredentialCache _creds = new CredentialCache();

		//default constuctor
		public ClientAuthenticationProvider() { }
		
		//constructor with properties
		public ClientAuthenticationProvider(IDictionary properties, ICollection providerData) 
		{
			//populate CredentialCache using the config file
			foreach (SinkProviderData spdCredentials in providerData) 
			{
				string url = (String)spdCredentials.Properties["serverObjectUrl"];
				Uri uri = new Uri(url);
				foreach (SinkProviderData spdCredential in spdCredentials.Children)
				{
					string userName = (String)spdCredential.Properties["userName"];
					string password = (String)spdCredential.Properties["password"];
					string domain = (String)spdCredential.Properties["domain"];
					NetworkCredential cred = new NetworkCredential(userName, password, domain);
					foreach (SinkProviderData spdAuthentication in spdCredential.Children)
					{
						string mode = (String)spdAuthentication.Properties["mode"];
						_creds.Add(uri, mode, cred);
					}
				}
			}
		}
		
		//IClientChannelSinkProvider.CreateSink method implimentation
		public IClientChannelSink CreateSink(IChannelSender channel, string url, object remoteChannelData)
		{
			IClientChannelSink nextSink = null;
			if (_nextProvider != null)
			{
				nextSink = _nextProvider.CreateSink(channel, url, remoteChannelData);
				if (nextSink == null)
					return null;
			}
			nextSink.Properties["credentials"] = _creds;
			return nextSink;
		}
		
		//IClientChannelSinkProvider.Next property implimentation
		public IClientChannelSinkProvider Next
		{
			get { return _nextProvider; }
			set { _nextProvider = value; }
		}

	}

}
