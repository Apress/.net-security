using System;
using System.Runtime.Remoting;
using LibraryServer;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Net;

namespace LibraryClientHost
{
	class Host
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Library client host started.\n");
			RemotingConfiguration.Configure("LibraryClientHost.exe.config");
			Library lib = new Library();
			
			/*
			IDictionary httpChannelProps = ChannelServices.GetChannelSinkProperties(lib);
			NetworkCredential cred = new NetworkCredential("LibraryUser", "password", "SHADOWFAX");
			Uri uri = new Uri("http://shadowfax/LibraryServerIISHost");
			CredentialCache credCache = new CredentialCache();
			credCache.Add(uri, "NTLM", cred);
			credCache.Add(uri, "Basic", cred);
			httpChannelProps["credentials"] = credCache;
			*/

			try
			{
				Console.WriteLine(
					"Remoting Library object user info:\n\n" + lib.GetUserInfo());
				Console.WriteLine("\nTotal books = {0}", lib.TotalBooks);
			}
			catch (Exception e)
			{
				Console.WriteLine(
					"Exception occurred when invoking Library.GetUserInfo:\n");
				Console.WriteLine(e.ToString());
			}
			Console.WriteLine("\nPress enter to shut down.");
			Console.ReadLine();
		}
	}
}
