using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting.Messaging;
using System.Net;
using System.Collections;
using System.IO;
using System.Web;

namespace LibraryServerMemberRBSSink
{

	public class ServerMemberRBSProvider : IServerFormatterSinkProvider, 
		IServerChannelSinkProvider
	{
		private IServerChannelSinkProvider _nextProvider = null;
		private ICollection _types;

		public ServerMemberRBSProvider() { }

		public ServerMemberRBSProvider(IDictionary properties, ICollection providerData) 
		{
			_types = providerData;
		}

		public void GetChannelData(IChannelDataStore channelData) { }
	
		public IServerChannelSink CreateSink(IChannelReceiver channel)
		{
			IServerChannelSink nextSink = null;
			if (_nextProvider != null)
				nextSink = _nextProvider.CreateSink(channel);
			return new ServerMemberRBSSink(nextSink, _types);
		}

		public IServerChannelSinkProvider Next
		{
			get { return _nextProvider; }
			set { _nextProvider = value; }
		}

	}
	
	public class ServerMemberRBSSink : BaseChannelObjectWithProperties, 
		IServerChannelSink
	{
		private IServerChannelSink _nextSink = null;
		private ICollection _types;

		public ServerMemberRBSSink(
			IServerChannelSink nextSink, ICollection types) : base()
		{
			_nextSink = nextSink;
			_types = types;
		}

		public ServerProcessing ProcessMessage(
			IServerChannelSinkStack sinkStack, 
			IMessage requestMsg, ITransportHeaders requestHeaders, 
			Stream requestStream, out IMessage responseMsg, 
			out ITransportHeaders responseHeaders, 
			out Stream responseStream)
		{
			string requestTypeName = 
				(String)requestMsg.Properties["__TypeName"];
			string requestMethodName = 
				(String)requestMsg.Properties["__MethodName"];
			string userName = HttpContext.Current.User.Identity.Name;
			bool accept = true;
			foreach (SinkProviderData spdType in _types)
			{
				string typeName = (String)spdType.Properties["type"];	
				string requestTypeNameSub = 
					requestTypeName.Substring(0, typeName.Length);
				if (typeName == requestTypeNameSub)
				{
					foreach (SinkProviderData spdMember 
								 in spdType.Children)
					{
						string memberType = spdMember.Name;
						string memberName = (String)spdMember.Properties["name"];
						string allowUser = (String)spdMember.Properties["allowUser"];
						bool memberMatch = false;
						switch(memberType)
						{
							case "method":
								if (memberName == requestMethodName)
									memberMatch = true;
								break;
							case "property":
								if (("get_" + memberName == requestMethodName) || 
									("set_" + memberName == requestMethodName))
									memberMatch = true;
								break;
						}
						if (memberMatch)
						{
							if(allowUser.ToLower() == userName.ToLower())
								accept = true;
							else 
								accept = false;
							break;
						}
					}
					break;
				}
			}
			if (accept)
			{   
				return _nextSink.ProcessMessage(sinkStack, requestMsg, 
					requestHeaders, null, out responseMsg, 
					out responseHeaders, out responseStream);
			}
			else
			{
				responseHeaders = new TransportHeaders();
				responseHeaders["__HttpStatusCode"] = "401";
				responseMsg = null;
				responseStream = null;
				return ServerProcessing.Complete;
			} 
		}

		public void AsyncProcessResponse(
			IServerResponseChannelSinkStack sinkStack, 
			Object state, IMessage msg, 
			ITransportHeaders headers, Stream stream) {}

		public Stream GetResponseStream(
			IServerResponseChannelSinkStack sinkStack, 
			Object state, IMessage msg, ITransportHeaders headers)
		{ return null; }

		public IServerChannelSink NextChannelSink
		{
			get { return _nextSink; }
		}

	}

}
