The LibraryServerIISHost directory needs to physically be located within IIS.
The SimpleLibraryInIIS Visual Studio.NET solution will not open all of its projects unless it is.
To make this work, do the following:

- Copy this directory to C:\Inetpub\wwwroot
- Create a virtual directory within the IIS Default Website called "LibraryServerIISHost" 
  and point it at the C:\Inetpub\wwwroot\LibraryServerIISHost directory.

