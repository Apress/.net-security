using System;
using System.Web;
using System.Security.Principal;

namespace LibraryServer
{
	public class Library : MarshalByRefObject
	{
		public Library() 
		{
			Console.WriteLine("Library class instantiated.");
		}
		public int GetAvailableCopies(int ISBN) 
		{
			switch (ISBN)
			{
				case 1893115593:
					return 3;
				case 1893115585:
					return 2;
				case 1893115712:
					return 0;
				default:
					return -1;
			}
		}
		public string GetUserInfo()
		{
			string authenticatedUser;
			string userName = HttpContext.Current.User.Identity.Name;
			if(userName == null || userName.Equals(string.Empty)) 
			{
				authenticatedUser = "  {Unavailable}";
			}
			else 
			{
				authenticatedUser = "  Username = " + userName + "\n" 
					+ "  Authentication Type = " +	
					HttpContext.Current.User.Identity.AuthenticationType;
			}
			string identityUser = "  " + WindowsIdentity.GetCurrent().Name;
			return "Authenticated User:\n" + 
				authenticatedUser + "\n" + 
				"Impersonated User:\n" + identityUser;
		}
	}
}
