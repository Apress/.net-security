using System;
using System.Runtime.Remoting;
using LibraryServer;
namespace LibraryClientHost
{
	class Host
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Library client host started.\n");
			RemotingConfiguration.Configure("LibraryClientHost.exe.config");
			Library lib = new Library();

			int intISBN = 1893115585;
			Console.Write("Copies of book (ISBN = " + intISBN.ToString() + "): ");
			Console.WriteLine(lib.GetAvailableCopies(1893115585));
			Console.WriteLine("\nPress enter to shut down.");
			Console.ReadLine();
		}
	}
}
