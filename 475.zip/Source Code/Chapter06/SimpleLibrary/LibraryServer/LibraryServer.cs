using System;
namespace LibraryServer
{
	public class Library : MarshalByRefObject
	{
		public Library() 
		{
			Console.WriteLine("Library class instantiated.");
		}
		public int GetAvailableCopies(int ISBN) 
		{
			switch (ISBN)
			{
				case 1893115593:
					return 3;
				case 1893115585:
					return 2;
				case 1893115712:
					return 0;
				default:
					return -1;
			}
		}
	}
}
