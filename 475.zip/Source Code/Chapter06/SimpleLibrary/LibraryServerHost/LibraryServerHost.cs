using System;
using System.Runtime.Remoting;
namespace LibraryServerHost
{
	class Host
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Library server host started.");
			RemotingConfiguration.Configure("LibraryServerHost.exe.config");
			Console.WriteLine("Press enter to shut down.\n");
			Console.ReadLine();
		}
	}
}
