using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Web.Security;

namespace ExplorePassport 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{

		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}
		

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion
	}

	public class	PassportUtilities
	{
		HttpContext	_currentContext;

		public enum	PPUIDReturnType
		{
			PRT_GUID,
			PRT_INT64,
			PRT_UINT64
		}

		public					PassportUtilities()
		{	
			_currentContext=HttpContext.Current;
		}
		public void				SignoutPassport()
		{
			ClearCookie(_currentContext.Response.Cookies["MSPAuth"]);
			ClearCookie(_currentContext.Response.Cookies["MSPProf"]);	
		}
		public void				SetSecureCookie(string cookieName, string cookieValue)
		{
			string	secureValue;
			
			// encrypt the data that�s going to be stored in the cookie � compress the data
			// prior to encrypting it to save storage space
			secureValue=PassportIdentity.Encrypt(PassportIdentity.Compress(cookieValue));
	
			// check and see if the cookie exists, if it doesn�t, we want to create it � if so, 
			// we�ll just set the existing value
			if (_currentContext.Response.Cookies[cookieName]==null)
			{
				_currentContext.Response.Cookies.Add(new HttpCookie(cookieName,secureValue));
			}
			else
			{
				_currentContext.Response.Cookies[cookieName].Value=secureValue;
			}

		}
		public string			ReadSecureCookie(string cookieName)
		{
			HttpCookie	cookieToRead;

			cookieToRead=_currentContext.Response.Cookies[cookieName];

			if (cookieToRead==null)
				return "";

			return PassportIdentity.Decompress(PassportIdentity.Decrypt(cookieToRead.Value));
			
		}
		public object			GetPassportID(PPUIDReturnType	typeToReturn)
		{
			string	currentID;

			currentID=((PassportIdentity)_currentContext.User.Identity).HexPUID;

			switch(typeToReturn)
			{
				case	PPUIDReturnType.PRT_GUID:
					return	PPUIDtoGUID(currentID);
					
				case PPUIDReturnType.PRT_INT64:
					return	PPUIDtoInt64(currentID);

				case PPUIDReturnType.PRT_UINT64:
					return	PPUIDtoUInt64(currentID);
			}

			return null;
		}
		
		public bool				HasStorageConsent
		{
			get
			{
				HttpCookie	consentCookie;

				consentCookie=_currentContext.Response.Cookies["PassportHasStorageConsent"];

				if (consentCookie!=null)
				{
					return Convert.ToBoolean(consentCookie.Value);
				}

				return false;
			}
			set
			{
				HttpCookie	consentCookie;

				consentCookie=_currentContext.Response.Cookies["PassportHasStorageConsent"];
				
				if (consentCookie==null)
				{
					consentCookie=new  HttpCookie("PassportHasStorageConsent",Convert.ToString(value));
					consentCookie.Expires=DateTime.Now.AddYears(5);
					consentCookie.Path="/";
					consentCookie.Domain="sfnphxdelivery.net";
					_currentContext.Response.Cookies.Add(consentCookie);
					
				}
				else
				{
					consentCookie.Value=Convert.ToString(value);
					_currentContext.Response.Cookies.Set(consentCookie);
				}
			}
		}
		public static string	ReadSecureCookie(HttpCookie	cookieToRead)
		{
			string 	unsecureVal;
	
			// read the value from the existing cookie, decrypt it and decompress it � you may 
			// want to add a trap to make sure the cookie being passed !=null

			unsecureVal=cookieToRead.Value;
			unsecureVal =PassportIdentity.Decompress(PassportIdentity.Decrypt(unsecureVal));
			return unsecureVal;
		}
		public static void		ClearCookie(HttpCookie cookieToClear)
		{
			cookieToClear.Expires=DateTime.Now.AddYears(-1);
			cookieToClear.Value="";
			cookieToClear.Path="/";
		}

		
		public static Guid		PPUIDtoGUID(string passportID)
		{
			string ppGUID;

			ppGUID="00000000-0000-0000-" + passportID.Substring(0,4) + "-" + passportID.Substring(4);
			return new System.Guid(ppGUID);
		}
		public static Int64		PPUIDtoInt64(string passportID)
		{
			return	System.Convert.ToInt64(passportID,16);
		}
		public static UInt64	PPUIDtoUInt64(string passportID)
		{
			return	System.Convert.ToUInt64(passportID,16);
		}
		
	}
}

