vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Jan 2002 07:04:24 -0000
vti_extenderversion:SR|4.0.2.4426
vti_nexttolasttimemodified:TR|21 Jan 2002 07:42:00 -0000
vti_author:SR|MORDOR\\Administrator
vti_timecreated:TR|23 Jan 2002 23:46:46 -0000
vti_cacheddtm:TX|23 Jan 2002 23:46:46 -0000
vti_filesize:IR|1305
vti_backlinkinfo:VX|
