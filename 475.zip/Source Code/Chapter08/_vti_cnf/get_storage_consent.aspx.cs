vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Jan 2002 21:15:09 -0000
vti_extenderversion:SR|4.0.2.4426
vti_nexttolasttimemodified:TR|24 Jan 2002 20:48:13 -0000
vti_author:SR|MORDOR\\Administrator
vti_modifiedby:SR|MORDOR\\Administrator
vti_timecreated:TR|24 Jan 2002 20:43:21 -0000
vti_filesize:IR|1354
vti_backlinkinfo:VX|
vti_cacheddtm:TX|24 Jan 2002 21:15:09 -0000
