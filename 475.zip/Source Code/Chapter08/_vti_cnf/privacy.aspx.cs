vti_encoding:SR|utf8-nl
vti_author:SR|MORDOR\\Administrator
vti_modifiedby:SR|MORDOR\\Administrator
vti_timecreated:TR|24 Jan 2002 18:04:59 -0000
vti_timelastmodified:TR|24 Jan 2002 18:04:59 -0000
vti_cacheddtm:TX|24 Jan 2002 18:04:59 -0000
vti_filesize:IR|1052
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
