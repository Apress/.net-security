vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Jan 2002 22:49:37 -0000
vti_extenderversion:SR|4.0.2.4426
vti_nexttolasttimemodified:TR|20 Jan 2002 08:48:52 -0000
vti_author:SR|MORDOR\\Administrator
vti_modifiedby:SR|MORDOR\\Administrator
vti_timecreated:TR|21 Jan 2002 22:49:37 -0000
vti_cacheddtm:TX|21 Jan 2002 22:49:37 -0000
vti_filesize:IR|1079
vti_backlinkinfo:VX|
