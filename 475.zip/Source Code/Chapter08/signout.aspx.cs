using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

namespace ExplorePassport
{
	/// <summary>
	/// Summary description for signout.
	/// </summary>
	public class signout : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// add necessary headers 
			Response.AddHeader("pragma","no-cache");
			Response.AddHeader("cache-control","no-cache");
			Response.AddHeader("P3P","TST");
			
			// tell the browser to expect an image
			Response.ContentType="image/gif";

			// clear our cookies
			signoutPassport();

			//write the image to the stream
			Response.WriteFile(@"c:\inetpub\wwwroot\ExplorePassport\support\img\signout.gif");

		}
		private void	signoutPassport()
		{

			// clear the Passport specific cookies
			clearCookie(Response.Cookies["MSPAuth"]);
			clearCookie(Response.Cookies["MSPProf"]);

		}
		private void clearCookie(System.Web.HttpCookie cookieToDelete)
		{
			// if nothing was passed, exit the function
			if (cookieToDelete==null) return;
			// we need to set the cookie to expire in the past � subtracting a year from the 
			// present should be a sufficient way to accomplish this � also, clear the value 
			cookieToDelete.Expires=DateTime.Now.AddYears(-1);
			cookieToDelete.Value="";
			cookieToDelete.Path="/";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
