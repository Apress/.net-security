vti_encoding:SR|utf8-nl
vti_author:SR|MORDOR\\Administrator
vti_timecreated:TR|20 Jan 2002 23:41:47 -0000
vti_timelastmodified:TR|23 Jan 2002 22:36:37 -0000
vti_filesize:IR|611
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|23 Jan 2002 19:39:22 -0000
vti_modifiedby:SR|MORDOR\\Administrator
vti_cacheddtm:TX|23 Jan 2002 19:39:22 -0000
