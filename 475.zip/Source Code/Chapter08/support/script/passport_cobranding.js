var CBLoginHead="<link type=text/css rel=stylesheet href=http://apress.sfnphxdelivery.net/support/css/passport_cobranding.css";

var CBLoginBody="<table border=0 cellpadding=0 cellspacing=0 align=center width=450>";
CBLoginBody+="<tr><td><img src=\"http://apress.sfnphxdelivery.net/ExplorePassport/support/img/passport_explore_468_60.gif\"></td></tr>";
CBLoginBody+="<tr><td class=itemText><br><b>Welcome to the Exploring Passport sample application</b>.<br><br>Please use your .Net Passport to sign in.";
CBLoginBody+="<tr><td>PASSPORT_UI</td></tr>";
CBLoginBody+="</table>";

var CBLoginOnLoad="";

